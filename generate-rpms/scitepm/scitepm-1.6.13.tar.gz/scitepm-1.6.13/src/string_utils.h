#ifndef STRING_UTILS_H
#define STRING_UTILS_H


#include <glib.h>


// Append a string to a (possibly) existing string

bool str_append(gchar **dst, const gchar *src, GError **err);


// Convert an absolute file path to a relative file path

bool abs_path_to_relative_path(const gchar *absPath, gchar **relativePath, const gchar *basePath, GError **err);


// Convert a relative file path to an absolute file path

bool relative_path_to_abs_path(gchar *relativePath, gchar **absPath, const gchar *basePath, GError **err);


#endif
