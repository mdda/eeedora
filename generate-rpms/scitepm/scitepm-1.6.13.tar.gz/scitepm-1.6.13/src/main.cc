/* main.cc - main for scitepm
 *
 *  Copyright 2006 Roy Wood
 *
 * scitepm is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * scitepm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with scitepm; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "gui.h"
#include "tree_manipulation.h"
#include "prefs.h"

#include <gtk/gtk.h>
#include <string.h>




// Main street....

int main(int argc, char *argv[])
{
	int returnCode = -1;
	GError *err = NULL;
	
	
	// Init gtk
	
	gtk_init(&argc, &argv);
	
	
	// Init scitepm prefs
	
	init_prefs();

	
	// Parse args

	for (int i = 1; i < argc; ++i) {
		if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--version") == 0) {
			show_version();
		}
		else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
			show_usage();
		}
		else if (strcmp(argv[i], "--nolhs") == 0) {
			gPrefs.lhs = 0;
		}
		else if (strcmp(argv[i], "--verbose") == 0) {
			gPrefs.verbosity = 100;
		}
		else {
			continue;
		}
		
		// Delete consumed arg
		
		memmove(&(argv[i]), &(argv[i+1]), (argc - i) * sizeof(char *));
		--argc;
		--i;
	}
	
	
	
	// Set up the GUI
	
	if (!setup_gui(&err)) {
		g_print("Could not initialize application globals: %s\n", err->message);
		goto EXITPOINT;
	}
	
	
	// Was a project file specified on the command line?
	
	if (argc > 1) {
		if (!load_project(argv[1], &err)) {
			GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while trying to load the specified project file: %s", err->message);
			gtk_dialog_run(GTK_DIALOG(errDialog));
			gtk_widget_destroy(errDialog);
			
			if (err) {
				g_error_free(err);
				err = NULL;
			}
		}
	}
	
	
	// Run the app
	
	gtk_main();
	
	
	returnCode = 0;
	
	
EXITPOINT:
	
	if (err) g_error_free(err);
	
	return returnCode;
}
