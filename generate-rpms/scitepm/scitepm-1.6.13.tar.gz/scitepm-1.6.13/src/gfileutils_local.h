#ifndef GFILEUTILS_LOCAL_H
#define GFILEUTILS_LOCAL_H

extern gboolean g_file_set_contents (const gchar *filename, const gchar *contents, gssize length, GError **error);


#endif
