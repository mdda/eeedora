/* string_utils.cc - misc string utils for scitepm
 *
 *  Copyright 2006 Roy Wood
 *
 * scitepm is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * scitepm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with scitepm; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


#include "string_utils.h"

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>


#define APP_SCITEPM_ERROR g_quark_from_static_string("APP_STRINGUTILS_ERROR")



/**
 * Convert an absolute file path to a relative file path.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param absPath is the absolute file path
 * @param relativePath returns the relative file path (must be later freed with g_free() )
 * @param basePath is the base file path against which the relative path is determined; pass NULL if the current working directory should be used as the base path
 * @param err returns any errors
 */
bool abs_path_to_relative_path(const gchar *absPath, gchar **relativePath, const gchar *basePath, GError **err)
{
	g_assert(absPath != NULL);
	g_assert(relativePath != NULL);
	
	bool finalResult = FALSE;
	gchar *localBasePath = NULL;
	char *workingDir = NULL;
	int localBasePathLength = 0;
	int absPathLength = strlen(absPath);
	int i = 0;
	int dirSlashOffset = 0;
	
	
	if (absPath[0] != '/') {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Specified path, '%s', is not absolute", __func__ , absPath);
		
		goto EXITPOINT;
	}
	
	
	// If no basepath specified, use current working dir
	
	if (!basePath) {
		workingDir = getcwd(NULL, 0);
		
		if (!workingDir) {
			g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not determine current working directory, getcwd() = NULL, errno = %d", __func__ , errno);
			
			goto EXITPOINT;
		}
		
		basePath = workingDir;
	}
	
	
	// Set up a local copy of the base path, and ensure it ends with a '/'
	
	if (!str_append(&localBasePath, basePath, err)) {
		goto EXITPOINT;
	}
	
	localBasePathLength = strlen(localBasePath);
	
	if (localBasePathLength <= 0 || localBasePath[localBasePathLength - 1] != '/') {
		if (!str_append(&localBasePath, "/", err)) {
			goto EXITPOINT;
		}
		
		++localBasePathLength;
	}
	
	
	// Start relative path with local dir
	
	if (!str_append(relativePath, "./", err)) {
		goto EXITPOINT;
	}
	
	// Skip over matching parent dirs
	
	while (localBasePath[i] == absPath[i] && i < localBasePathLength && i < absPathLength) {
		if (absPath[i] == '/') {
			dirSlashOffset = i + 1;
		}
		
		++i;
	}
	
	// Step up one dir for every dir in the leftover part of the base path
	
	for (i = dirSlashOffset; i < localBasePathLength; ++i) {
		if (localBasePath[i] == '/') {
			if (!str_append(relativePath, "../", err)) {
				goto EXITPOINT;
			}
		}
	}
	
	// Finally, add the leftover part of the absolute path
	
	if (!str_append(relativePath, absPath + dirSlashOffset, err)) {
		goto EXITPOINT;
	}
	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (workingDir) free(workingDir);
	if (localBasePath) g_free(localBasePath);
	
	return finalResult;
}



/**
 * Convert a relative file path to an absolute file path.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param relativePath is the relative file path
 * @param absPath returns the absolute file path (must be later freed with g_free() )
 * @param basePath is the base file path used to formulate the absolute path; pass NULL if the current working directory should be used as the base path
 * @param err returns any errors
 */
bool relative_path_to_abs_path(gchar *relativePath, gchar **absPath, const gchar *basePath, GError **err)
{
	g_assert(absPath != NULL);
	g_assert(relativePath != NULL);
	
	bool finalResult = FALSE;
	char *workingDir = NULL;
	gchar *localAbsPath = NULL;
	int absPathLength;
	
	
	if (relativePath[0] == '/') {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Specified path, '%s', is absolute", __func__ , relativePath);
		
		goto EXITPOINT;
	}
	
	
	// If no basepath specified, use current working dir
	
	if (!basePath) {
		workingDir = getcwd(NULL, 0);
		
		if (!workingDir) {
			g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not determine current working directory, getcwd() = NULL, errno = %d", __func__, errno);
			
			goto EXITPOINT;
		}
		
		basePath = workingDir;
	}
	
	
	// Absolute path is base path + '/' + relative path
	
	if (!str_append(&localAbsPath, basePath, err)) {
		goto EXITPOINT;
	}
	
	if (!str_append(&localAbsPath, "/", err)) {
		goto EXITPOINT;
	}
	
	if (!str_append(&localAbsPath, relativePath, err)) {
		goto EXITPOINT;
	}
	
	
	// Now go through and collapse elements like  "/./" and "/foo/../" and "//"
	
	absPathLength = strlen(localAbsPath);
	
	for (int i = 0; i < absPathLength; ) {
		gchar *tail = NULL;
		int tailLength;
		
		if (g_str_has_prefix(localAbsPath + i, "/./")) {
			tail = localAbsPath + i + 2;
			tailLength = absPathLength - i - 1;
		}
		else if (g_str_has_prefix(localAbsPath + i, "//")) {
			tail = localAbsPath + i + 1;
			tailLength = absPathLength - i;
		}
		else if (g_str_has_prefix(localAbsPath + i, "/../")) {
			tail = localAbsPath + i + 3;
			tailLength = absPathLength - i - 2;
			
			do {
				i = (i > 0) ? i - 1 : 0;
			} while (i > 0 && localAbsPath[i] != '/');
		}
		
		if (tail != NULL) {
			g_memmove(localAbsPath + i, tail, tailLength);
			
			absPathLength -= (tail - localAbsPath - i);
		}
		else {
			++i;
		}
	}
	
	*absPath = localAbsPath;
	
	localAbsPath = NULL;
	
	finalResult = TRUE;
	
EXITPOINT:
	
	if (workingDir) free(workingDir);
	if (localAbsPath) g_free(localAbsPath);
	
	return finalResult;
}





/**
 * Append a string to an existing string, expanding the allocation of the string.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param dst is the string to append onto
 * @param src is the string to append to dst
 * @param err returns any errors
 */
bool str_append(gchar **dst, const gchar *src, GError **err)
{
	bool finalResult = FALSE;
	
	g_assert(dst != NULL);
	g_assert(src != NULL);
	
	gulong dstLength = (*dst == NULL) ? 0 : strlen(*dst);
	gulong srcLength = strlen(src);
	gulong totalLength = dstLength + srcLength + 1;
	
	gchar *newDst = (gchar *) g_try_realloc(*dst, totalLength);
	
	if (newDst == NULL) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not allocate memory, g_try_realloc(%ld) = NULL", __func__, totalLength);
		
		goto EXITPOINT;
	}
	
	g_memmove(newDst + dstLength, src, srcLength + 1);
	
	*dst = newDst;
	
	finalResult = TRUE;

EXITPOINT:
	
	return finalResult;
}
