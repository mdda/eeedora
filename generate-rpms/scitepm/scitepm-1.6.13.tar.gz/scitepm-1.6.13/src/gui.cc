/* gui.cc - GUI code for scitepm
 *
 *  Copyright 2006 Roy Wood
 *
 * scitepm is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * scitepm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with scitepm; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


#include "gui.h"
#include "drag_drop.h"
#include "tree_manipulation.h"
#include "scite_utils.h"
#include "string_utils.h"
#include "prefs.h"

#include <string.h>
#include <glib.h>
#include <gtk/gtk.h>
#include <gdk/gdkx.h>


#define APP_SCITEPM_ERROR g_quark_from_static_string("APP_GUI_ERROR")



// Forward-declare static functions

static gint window_delete_event_cb(GtkWidget *widget, GdkEvent *event, gpointer data);
static void tree_row_activated_cb(GtkTreeView *treeView, GtkTreePath *path, GtkTreeViewColumn *column, gpointer userData);
static gboolean mouse_button_pressed_cb(GtkWidget *treeView, GdkEventButton *event, gpointer userData);

static void entry_widget_activated_cb(GtkEntry *entry, gpointer dialog);

static void ask_name_add_group(GtkTreeIter *nodeIter);

static void row_expand_or_collapse_cb(GtkTreeView *treeview, GtkTreeIter *arg1, GtkTreePath *arg2, gpointer user_data);

static void menu_add_widget_cb(GtkUIManager *ui, GtkWidget *widget, GtkContainer *container);

static void show_about_dialog() ;

static void quit_menu_cb();
static void about_menu_cb();
static void usage_menu_cb();
static void saveproject_menu_cb();
static void openproject_menu_cb();
static void addfile_menu_cb();
static void creategroup_menu_cb();

static void popup_add_files_cb();
static void popup_open_file_cb();
static void popup_add_group_cb();
static void popup_remove_node_cb();
static void popup_rename_group_cb();





// Menu definitions

static gchar *sMenuDefXML = \
	"<ui> \
		<menubar> \
			<menu name=\"FileMenu\" action=\"FileMenuAction\"> \
				<menuitem name=\"OpenProjectItem\" action=\"OpenProjectAction\" /> \
				<menuitem name=\"SaveProjectItem\" action=\"SaveProjectAction\" /> \
				<separator/> \
				<menuitem name=\"ExitItem\" action=\"ExitAction\" /> \
			</menu> \
			<menu name=\"EditMenu\" action=\"EditMenuAction\"> \
				<menuitem name=\"CreateGroupItem\" action=\"CreateGroupAction\" /> \
				<menuitem name=\"AddFileItem\" action=\"AddFileAction\" /> \
			</menu> \
			<menu name=\"HelpMenu\" action=\"HelpMenuAction\"> \
				<menuitem name=\"UsageItem\" action=\"UsageAction\"/> \
				<menuitem name=\"AboutItem\" action=\"AboutAction\"/> \
			</menu> \
		</menubar> \
		<popup name=\"GeneralPopup\" action=\"GeneralPopupAction\"> \
			<menuitem name=\"AddFilesPopupItem\" action=\"AddFilesPopupAction\"/> \
			<menuitem name=\"AddGroupPopupItem\" action=\"AddGroupPopupAction\"/> \
		</popup> \
		<popup name=\"FilePopup\" action=\"FilePopupAction\"> \
			<menuitem name=\"OpenFilePopupItem\" action=\"OpenFilePopupAction\"/> \
			<menuitem name=\"RemoveFilePopupItem\" action=\"RemoveFilePopupAction\"/> \
		</popup> \
		<popup name=\"GroupPopup\" action=\"GroupPopupAction\"> \
			<menuitem name=\"AddFilesToGroupPopupItem\" action=\"AddFilestoGroupPopupAction\"/> \
			<menuitem name=\"AddSubgroupPopupItem\" action=\"AddSubgroupPopupAction\"/> \
			<menuitem name=\"RenameGroupPopupItem\" action=\"RenameGroupPopupAction\"/> \
			<menuitem name=\"RemoveGroupPopupItem\" action=\"RemoveGroupPopupAction\"/> \
		</popup> \
	</ui>";



static GtkActionEntry sMenuActions[] = 
{
	{ "FileMenuAction", NULL, "_File" },
	{ "EditMenuAction", NULL, "_Edit" },
	{ "HelpMenuAction", NULL, "_Help" },
	
	{ "OpenProjectAction", GTK_STOCK_OPEN, "_Open Project", "<control>O", "Open Project", G_CALLBACK(openproject_menu_cb) },
	{ "SaveProjectAction", GTK_STOCK_SAVE, "_Save Project", "<control>S", "Save Project", G_CALLBACK(saveproject_menu_cb) },
	{ "ExitAction", GTK_STOCK_QUIT, "_Exit", "<control>Q", "Exit", G_CALLBACK(quit_menu_cb) },
	
	{ "CreateGroupAction", GTK_STOCK_DIRECTORY, "Create _Group", "", "Create a group node in the project", G_CALLBACK(creategroup_menu_cb) },
	{ "AddFileAction", GTK_STOCK_FILE, "Add _File", "", "Add a file to the project", G_CALLBACK(addfile_menu_cb) },
	
	{ "UsageAction", GTK_STOCK_HELP, "_Usage", "", "Show command line usage", G_CALLBACK(usage_menu_cb) },
	{ "AboutAction", GTK_STOCK_ABOUT, "_About", "", "Show information about this application", G_CALLBACK(about_menu_cb) },
	
	{ "AddFilesPopupAction", GTK_STOCK_FILE, "Add Files", "", "Add files to the project", G_CALLBACK(popup_add_files_cb) },
	{ "AddGroupPopupAction", GTK_STOCK_DIRECTORY, "Add Group", "", "Add a group to the project", G_CALLBACK(popup_add_group_cb) },
	
	{ "AddFilestoGroupPopupAction", GTK_STOCK_FILE, "Add Files to Group", "", "Add files to an existing group", G_CALLBACK(popup_add_files_cb) },
	{ "AddSubgroupPopupAction", GTK_STOCK_DIRECTORY, "Add Subgroup to Group", "", "Add a subgroup to an existing group", G_CALLBACK(popup_add_group_cb) },
	{ "RenameGroupPopupAction", GTK_STOCK_EDIT, "Rename Group", "", "Rename a group", G_CALLBACK(popup_rename_group_cb) },
	{ "RemoveGroupPopupAction", GTK_STOCK_DELETE, "Remove Group From Project", "", "Remove a group and its children from the project", G_CALLBACK(popup_remove_node_cb) },
	
	{ "OpenFilePopupAction", GTK_STOCK_OPEN, "Open File in SciTE", "", "Open a file in SciTE", G_CALLBACK(popup_open_file_cb) },
	{ "RemoveFilePopupAction", GTK_STOCK_DELETE, "Remove File From Project", "", "Remove a file from the project", G_CALLBACK(popup_remove_node_cb) }

};

static guint sNumMenuActions = G_N_ELEMENTS(sMenuActions);


static gchar *sLicense =	"ScitePM is free software; you can redistribute it and/or modify it\n"
							"under the terms of the GNU General Public License as published\n"
							"by the Free Software Foundation; either version 2 of the License,\n"
							"or (at your option) any later version.\n"
							"\n"
							"ScitePM is distributed in the hope that it will be useful, but\n"
							"WITHOUT ANY WARRANTY; without even the implied warranty of\n"
							"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See\n"
							"the GNU General Public License for more details.\n"
							"\n"
							"You should have received a copy of the GNU General Public License\n"
							"along with ScitePM.  If not, write to:\n"
							"\n"
							"Free Software Foundation, Inc.\n"
							"59 Temple Place - Suite 330\n"
							"Boston, MA, USA\n"
							"02111-1307";

static gchar *sAuthors[] = { "Roy Wood <roy.wood@gmail.com>", "Martin Andrews <ScitePM@PLATFORMedia.com>", NULL };

static gchar *sVersion = "1.6.13";

static gchar *sUsage = "scitepm [-v|--version] [-h|--help] [--nolhs] [--verbose] [project-path]";


static TreeViewDragStruct sDragStruct;

static GtkWidget *sMainWindow = NULL;
static GtkWidget *sTreeView = NULL;

static GtkWidget *sGroupPopupMenu = NULL;
static GtkWidget *sFilePopupMenu = NULL;
static GtkWidget *sGeneralPopupMenu = NULL;

static bool sClickedNodeValid = FALSE;
static GtkTreeIter sClickedNodeIter;
static gchar *sClickedNodeName = NULL;
static gint sClickedNodeType = -1;

static GtkActionGroup *sActionGroup = NULL;
static GtkUIManager *sGtkUIManager = NULL;




/**
 * Initialize globals (i.e. create the main window and populate it).  This is a long chunk of code.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param err returns any errors
 */
bool setup_gui(GError **err)
{
	bool resultCode = FALSE;
	GtkTreeSelection *selection = NULL;
	GtkWidget *vbox = NULL;
	GtkCellRenderer *textCellRenderer = NULL;
	GtkCellRenderer *pixbuffCellRenderer = NULL;
	GtkTreeViewColumn *column1 = NULL;
	GtkTreeViewColumn *column2 = NULL;
	GtkWidget *scrolledWindow = NULL;
	GtkTargetEntry dragTargets[] = { { "text/uri-list", 0, DND_URI_TYPE } };
	GtkTreeStore *treeStore = NULL;
	GtkAccelGroup* accelgroup = NULL;
	GError *tempErr = NULL;
	
	
	// Create top-level window, configure it
	
	if (!(sMainWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create main window, gtk_window_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	gtk_window_set_title(GTK_WINDOW(sMainWindow), "ScitePM");
	gtk_window_set_default_size(GTK_WINDOW(sMainWindow), gPrefs.width, gPrefs.height);
	gtk_container_set_border_width(GTK_CONTAINER(sMainWindow), 3);
	g_signal_connect(G_OBJECT(sMainWindow), "delete_event", G_CALLBACK(window_delete_event_cb), NULL);
	
	
	// Main content of the window is a vbox
	
	if (!(vbox = gtk_vbox_new(FALSE, 2))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create main vbox, gtk_vbox_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	gtk_container_add(GTK_CONTAINER(sMainWindow), vbox);
	
	
	// Create menus
	
	if (!(sActionGroup = gtk_action_group_new("ScitepmActions"))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkActionGroup, gtk_action_group_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	if (!(sGtkUIManager = gtk_ui_manager_new())) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkUIManager, gtk_ui_manager_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	g_signal_connect(sGtkUIManager, "add_widget", G_CALLBACK(menu_add_widget_cb), vbox);
	
	gtk_action_group_add_actions(sActionGroup, sMenuActions, sNumMenuActions, NULL);
	
	gtk_ui_manager_insert_action_group(sGtkUIManager, sActionGroup, 0);
	
	if (gtk_ui_manager_add_ui_from_string(sGtkUIManager, sMenuDefXML, strlen(sMenuDefXML), &tempErr) == 0) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create create menus from XML, gtk_ui_manager_add_ui_from_string() = %s", __func__, tempErr->message);
		
		goto EXITPOINT;
	}
	
	gtk_ui_manager_ensure_update(sGtkUIManager);
	
	
	// Activate the keyboard accelerators
	
	accelgroup = gtk_ui_manager_get_accel_group(sGtkUIManager);
	gtk_window_add_accel_group(GTK_WINDOW(sMainWindow), accelgroup);
	
	
	// Create popup menus (shown when user right-clicks in gui elements)
	
	sGeneralPopupMenu = gtk_ui_manager_get_widget(sGtkUIManager, "/ui/GeneralPopup");
	sGroupPopupMenu = gtk_ui_manager_get_widget(sGtkUIManager, "/ui/GroupPopup");
	sFilePopupMenu = gtk_ui_manager_get_widget(sGtkUIManager, "/ui/FilePopup");
	
	
	
	
	// Add a scrolled window to the main window
	
	if (!(scrolledWindow = gtk_scrolled_window_new(NULL, NULL))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create main scrolled window, gtk_scrolled_window_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindow), GTK_POLICY_NEVER, GTK_POLICY_ALWAYS);
	
	gtk_box_pack_start(GTK_BOX(vbox), scrolledWindow, TRUE, TRUE, 0);
	
	
	// Create the tree datastore
	
	if ((treeStore = get_treestore(err)) == NULL) {
		goto EXITPOINT;
	}
	
	
	// Create the treeview, set it up to render the tree datastore, and add it to the hbox
	
	if (!(sTreeView = gtk_tree_view_new_with_model(GTK_TREE_MODEL(treeStore)))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkTreeView, gtk_tree_view_new_with_model() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	if (!(textCellRenderer = gtk_cell_renderer_text_new())) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkCellRenderer, gtk_cell_renderer_text_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	if (!(pixbuffCellRenderer = gtk_cell_renderer_pixbuf_new())) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkCellRenderer, gtk_cell_renderer_pixbuf_new() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	if (!(column1 = gtk_tree_view_column_new())) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkTreeViewColumn, gtk_tree_view_column_new() = NULL", __func__);
		
		goto EXITPOINT;
	}

	gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(sTreeView), FALSE);
	
//~ 	gtk_tree_view_column_set_title(column1, "File");
	gtk_tree_view_column_set_resizable(column1, TRUE);
	gtk_tree_view_column_set_min_width(column1, (int)(gPrefs.width*.75));
	
	gtk_tree_view_column_pack_start(column1, pixbuffCellRenderer, FALSE);
	gtk_tree_view_column_add_attribute(column1, pixbuffCellRenderer, "stock-id", COLUMN_STOCKITEM);
	
	gtk_tree_view_column_pack_start(column1, textCellRenderer, TRUE);
	gtk_tree_view_column_add_attribute(column1, textCellRenderer, "text", COLUMN_FILENAME);
	gtk_tree_view_column_add_attribute(column1, textCellRenderer, "weight", COLUMN_FONTWEIGHT);
	gtk_tree_view_column_add_attribute(column1, textCellRenderer, "weight-set", COLUMN_FONTWEIGHTSET);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(sTreeView), column1);
	
	
	if (!(column2 = gtk_tree_view_column_new_with_attributes("", textCellRenderer, "text", COLUMN_FILESIZE, NULL))) {
		g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkTreeViewColumn, gtk_tree_view_column_new_with_attributes() = NULL", __func__);
		
		goto EXITPOINT;
	}
	
	// Stoopid gtk always expands the last column
//~ 	gtk_tree_view_column_set_max_width(column2, 100);
	
	gtk_tree_view_append_column(GTK_TREE_VIEW(sTreeView), column2);
	
	gtk_container_add(GTK_CONTAINER(scrolledWindow), sTreeView);
	
	
	// Get tree events
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(sTreeView));
//~ 	gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE); 
	gtk_tree_selection_set_mode(selection, GTK_SELECTION_MULTIPLE);
	
//~ 	gtk_tree_selection_set_select_function(selection, tree_selection_cb, sTreeView, NULL);
	
	g_signal_connect(G_OBJECT(sTreeView), "row-activated", G_CALLBACK(tree_row_activated_cb), NULL);
	
	
	gtk_tree_view_enable_model_drag_source(GTK_TREE_VIEW(sTreeView), GDK_BUTTON1_MASK, dragTargets, 1, GDK_ACTION_MOVE);
	gtk_tree_view_enable_model_drag_dest(GTK_TREE_VIEW(sTreeView), dragTargets, 1, GDK_ACTION_MOVE);
	
	
	sDragStruct.treeView = GTK_TREE_VIEW(sTreeView);
	sDragStruct.treeStore = treeStore;
	sDragStruct.isLocalDrag = FALSE;
	sDragStruct.dragNodes = NULL;
	
	g_signal_connect(G_OBJECT(sTreeView), "drag-data-received", G_CALLBACK(drag_data_received_cb), &sDragStruct);
	g_signal_connect(G_OBJECT(sTreeView), "drag-data-get", G_CALLBACK(drag_data_get_cb), &sDragStruct);
	g_signal_connect(G_OBJECT(sTreeView), "drag-motion", G_CALLBACK(drag_motion_cb), &sDragStruct);
	g_signal_connect(G_OBJECT(sTreeView), "row-expanded", G_CALLBACK(row_expand_or_collapse_cb), NULL);
	g_signal_connect(G_OBJECT(sTreeView), "row-collapsed", G_CALLBACK(row_expand_or_collapse_cb), NULL);
	
	g_signal_connect(G_OBJECT(sTreeView), "button-press-event", G_CALLBACK(mouse_button_pressed_cb), sTreeView);
//~ 	g_signal_connect(G_OBJECT(sTreeView), "popup-menu", G_CALLBACK(popup_menu_cb), sTreeView);
//~ 	g_signal_connect(G_OBJECT(sTreeView), "key-press-event", G_CALLBACK(key_press_cb), sTreeView);
	
	
	
	// LHS version extends top-to-bottom on screen on left-hand side of screen
	
	if (gPrefs.lhs) {  
		int height;
		height = gdk_screen_height();
		
		gtk_window_resize(GTK_WINDOW(sMainWindow), gPrefs.width, height);
//		gtk_widget_set_uposition(GTK_WIDGET(sMainWindow),0,0); // This is deprecated now...
		gtk_window_move(GTK_WINDOW(sMainWindow),0,0);
	}
	
	
	// Show it all....
	
	gtk_widget_show(sTreeView);
	gtk_widget_show(scrolledWindow);
	gtk_widget_show(vbox);
	gtk_widget_show(sMainWindow);
	
//~ 	Window xid = GDK_WINDOW_XWINDOW(GTK_WIDGET(sMainWindow)->window);
//~ 	
//~ 	g_print("%s: xid = 0x%lX\n", __func__, (unsigned long) xid);
	
	
	resultCode = TRUE;
	
	
EXITPOINT:
	
	if (tempErr) g_error_free(tempErr);
	
	return resultCode;
}

void get_dimensions(gint *left, gint *top, gint *width, gint *height) {
//	gtk_window_get_position(GTK_WINDOW(sMainWindow), left, top); 
	gtk_window_get_size(GTK_WINDOW(sMainWindow), width, height);
	return;
}




/**
 * Determine whether a specified row in the tree is expanded.
 *
 * @return TRUE if the row is expanded; FALSE otherwise
 *
 * @param path is the GtkTreePath referencing the row
 */
bool tree_row_is_expanded(GtkTreePath *path)
{
	g_assert(path != NULL);
	
	return gtk_tree_view_row_expanded(GTK_TREE_VIEW(sTreeView), path);
}



/**
 * Expand a row in the tree.
 *
 * @param path is the GtkTreePath referencing the row
 * @param expandChildren indicates whether all children should be expanded
 */
void expand_tree_row(GtkTreePath *path, bool expandChildren)
{
	gtk_tree_view_expand_row(GTK_TREE_VIEW(sTreeView), path, expandChildren);
}



/**
 * Enable/disable the "Save Project" button.
 *
 * @param enabled indicates whether the button should be enabled or disabled
 */
void set_save_button_sensitivity(bool enabled)
{
//~ 	if (sSaveProjectButton) {
//~ 		gtk_widget_set_sensitive(GTK_WIDGET(sSaveProjectButton), enabled);
//~ 	}
}






/**
 * Callback for Gtk "delete_event" message for the top-level application window.
 *
 * @param widget is not used
 * @param event is not used
 * @param data is not used
 */
static gint window_delete_event_cb(GtkWidget *widget, GdkEvent *event, gpointer data)
{
	bool eventHandled = TRUE;
	
	prompt_user_to_save_project();
	
	if (!project_is_dirty()) {
		gtk_main_quit();
	}
	
	return eventHandled;
}



/**
 * Callback handler for Gtk "row-activated" event.
 *
 * @param treeView is the GtkTreeView
 * @param path is the GtkTreePath of the activated row
 * @param column is not used
 * @param userData is not used
 */
static void tree_row_activated_cb(GtkTreeView *treeView, GtkTreePath *path, GtkTreeViewColumn *column, gpointer userData)
{
	GtkTreeModel *treeModel = NULL;
	GtkTreeIter iter;
	gchar *relFilePath = NULL;
	gchar *absFilePath = NULL;
	gchar *command = NULL;
	GError *err = NULL;
	GtkWidget *dialog = NULL;
	gint nodeItemType;
	
	
	// Get the data from the row that was activated
	
	treeModel = gtk_tree_view_get_model(treeView);
	gtk_tree_model_get_iter(treeModel, &iter, path);
	gtk_tree_model_get(treeModel, &iter, COLUMN_ITEMTYPE, &nodeItemType, COLUMN_FILEPATH, &relFilePath, -1);
	
	
	// We can only open files
	
	if (nodeItemType != ITEMTYPE_FILE) {
		goto EXITPOINT;
	}
	
	if (!relative_path_to_abs_path(relFilePath, &absFilePath, get_project_directory(), &err)) {
		goto EXITPOINT;
	}
	
	
	// It's a file, so try to open it
	
	if ((command = g_strdup_printf("open:%s\n", absFilePath)) == NULL) {
		g_set_error(&err, APP_SCITEPM_ERROR, -1, "%s: Error formatting Scite director command, g_strdup_printf() = NULL", __func__);
	}
	else {
		if (send_scite_command(command, &err)) {
			// Try to activate SciTE; ignore errors
			
			activate_scite(NULL);
		}
	}
	
EXITPOINT:
	
	if (err != NULL) {
		dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "Could not open selected file: \n\n%s", err->message);
		
		gtk_dialog_run(GTK_DIALOG (dialog));
	}
	
	if (relFilePath) g_free(relFilePath);
	if (absFilePath) g_free(absFilePath);
	if (command) g_free(command);
	if (err) g_error_free(err);
	if (dialog) gtk_widget_destroy(dialog);
}



/**
 * Respond to a Gtk "button-press-event" message.
 *
 * @param treeView is the GTKTreeView widget in which the mouse-button event occurred
 * @param event is the GdkEventButton event object
 * @param userData is not currently used
 */
static gboolean mouse_button_pressed_cb(GtkWidget *treeView, GdkEventButton *event, gpointer userData)
{
	gboolean eventHandled = FALSE;
	GtkTreePath *path = NULL;
	GtkTreeModel *treeModel = NULL;
	gchar *nodeName = NULL;
	gint nodeItemType;
	GtkTreeIter iter;
	
	
	g_assert(treeView != NULL);
	g_assert(event != NULL);
	
	
	// Until we know for sure, assume that the user has not clicked on a node
	
	sClickedNodeValid = FALSE;
	
	
	// If it is not a right-click, then ignore it
	
	if (event->type != GDK_BUTTON_PRESS || event->button != 3) {
		goto EXITPOINT;
	}
	
	
	// Find if the user has clicked on a node
	
	if (!gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(treeView), (gint) event->x, (gint) event->y, &path, NULL, NULL, NULL)) {
		// Nope-- user clicked in the GtkTreeView, but not on a node
		
		gtk_menu_popup(GTK_MENU(sGeneralPopupMenu), NULL, NULL, NULL, NULL, event->button, gdk_event_get_time((GdkEvent*) event));
		
		goto EXITPOINT;
	}
	
	
	// User clicked on a node, so retrieve the particulars
	
	treeModel = gtk_tree_view_get_model(GTK_TREE_VIEW(treeView));
	
	if (!gtk_tree_model_get_iter(treeModel, &iter, path)) {
		goto EXITPOINT;
	}
	
	gtk_tree_model_get(treeModel, &iter, COLUMN_ITEMTYPE, &nodeItemType, COLUMN_FILEPATH, &nodeName, -1);
	
	
	// Save the node info for use by the popup menu callbacks
	
	if (sClickedNodeName) g_free(sClickedNodeName);
	sClickedNodeName = NULL;
	
	sClickedNodeValid = TRUE;
	sClickedNodeIter = iter;
	sClickedNodeType = nodeItemType;
	sClickedNodeName = nodeName;
	nodeName = NULL;
	
	
	// Pop up the appropriate menu for the node type
	
	if (nodeItemType == ITEMTYPE_FILE) {
		gtk_menu_popup(GTK_MENU(sFilePopupMenu), NULL, NULL, NULL, NULL, event->button, gdk_event_get_time((GdkEvent*) event));
	}
	else if (nodeItemType == ITEMTYPE_GROUP) {
		gtk_menu_popup(GTK_MENU(sGroupPopupMenu), NULL, NULL, NULL, NULL, event->button, gdk_event_get_time((GdkEvent*) event));
	}
	
	
	// We took care of the event, so no need to propogate it
	
	eventHandled = TRUE;
	
	
EXITPOINT:
	
	if (path) gtk_tree_path_free(path);
	if (nodeName) g_free(nodeName);
	
	return eventHandled;
}



/**
 * Add files to a group or the root of the tree
 */
static void popup_add_files_cb()
{
	GtkWidget *dialog = NULL;
	GError *err = NULL;
	GtkTreeIter *nodeIter = NULL;
	
	
	// Files cannot be added to files!
	
	if (sClickedNodeValid && sClickedNodeType == ITEMTYPE_FILE) {
		goto EXITPOINT;
	}
	
	
	// Add to the root or to a group?
	
	if (sClickedNodeValid) {
		nodeIter = &sClickedNodeIter;
	}
	
	if (!add_files_to_project(nodeIter, &err)) {
		dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while trying add files to the project: %s", err->message);
		
		gtk_dialog_run(GTK_DIALOG(dialog));
	}
	
	
EXITPOINT:
	
	if (err) g_error_free(err);
	if (dialog) gtk_widget_destroy(dialog);
}



/**
 * Open the selected file.
 */
static void popup_open_file_cb()
{
	gchar *command = NULL;
	GError *err = NULL;
	GtkWidget *dialog = NULL;
	gchar *absFilePath = NULL;
	
	
	// We can only open files
	
	if (!sClickedNodeValid || sClickedNodeType != ITEMTYPE_FILE) {
		goto EXITPOINT;
	}
	
	if (!relative_path_to_abs_path(sClickedNodeName, &absFilePath, get_project_directory(), &err)) {
		goto EXITPOINT;
	}
	
	
	// It's a file, so try to open it
	
	if ((command = g_strdup_printf("open:%s\n", absFilePath)) == NULL) {
		g_set_error(&err, APP_SCITEPM_ERROR, -1, "%s: Error formatting Scite director command, g_strdup_printf() = NULL", __func__);
	}
	else {
		if (send_scite_command(command, &err)) {
			// Try to activate SciTE; ignore errors
			
			activate_scite(NULL);
		}
	}
	
EXITPOINT:
	
	if (err != NULL) {
		dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "Could not open selected file: \n\n%s", err->message);
		
		gtk_dialog_run(GTK_DIALOG (dialog));
	}
	
	if (command) g_free(command);
	if (absFilePath) g_free(absFilePath);
	if (err) g_error_free(err);
	if (dialog) gtk_widget_destroy(dialog);	
}



/**
 * Remove the selected file/group.
 */
static void popup_remove_node_cb()
{
	GError *err = NULL;
	GtkWidget *dialog = NULL;
	gint dialogResponse;
	gchar *nodename = NULL;
	
	
	// Make sure a node has been selected
	
	if (!sClickedNodeValid) {
		goto EXITPOINT;
	}
	
	
	// Figure out the node name
	
	nodename = strrchr(sClickedNodeName, '/');
	
	if (nodename != NULL) {
		++nodename;
	}
	else {
		nodename = sClickedNodeName;
	}
	
	
	// Confirm removal from project
	
	if (sClickedNodeType == ITEMTYPE_FILE) {
		dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_OK_CANCEL, "Remove file '%s' from project?", nodename);
	}
	else {
		dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_OK_CANCEL, "Remove group '%s' and any contained files from project?", nodename);
	}
	
	dialogResponse = gtk_dialog_run(GTK_DIALOG (dialog));
	
	if (dialogResponse == GTK_RESPONSE_CANCEL) {
		goto EXITPOINT;
	}
	
	
	// Remove the node
	
	if (!remove_tree_node(&sClickedNodeIter, &err)) {
		GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "Could not remove the selected node: \n\n%s", err->message);
		
		gtk_dialog_run(GTK_DIALOG (errDialog));
		
		gtk_widget_destroy(errDialog);	
	}
	
EXITPOINT:
	
	if (err) g_error_free(err);
	if (dialog) gtk_widget_destroy(dialog);
}



/**
 * Add a group to the root of the tree, or to an existing group
 */
static void popup_add_group_cb()
{
	GtkTreeIter *nodeIter = NULL;
	
	
	// Groups cannot be added to files!
	
	if (sClickedNodeValid && sClickedNodeType == ITEMTYPE_FILE) {
		goto EXITPOINT;
	}
	
	
	// Are we adding this to the root of the tree, or to an existing group?
	
	if (sClickedNodeValid) {
		nodeIter = &sClickedNodeIter;
	}
	
	ask_name_add_group(nodeIter);
	
	
EXITPOINT:
	
	return;
}



/**
 * Callback to handle "activation" message from a GtkEntry widget.  This code allows a return/enter
 * keystroke to trigger dismissal of the dialog box containing the GtkEntry.
 *
 * @param entry is the GtkEntry widget
 * @param dialog is the dialog that contains the GtkEntry widget
 */
static void entry_widget_activated_cb(GtkEntry *entry, gpointer dialog)
{
	if (dialog != NULL) {
		gtk_dialog_response(GTK_DIALOG(dialog), GTK_RESPONSE_ACCEPT);
	}
}




/**
 * Set the title of the main window.
 *
 * @param newName is the desired new name of the window.
 */
void set_window_title(const gchar *newName)
{
	g_assert(newName != NULL);
	
	gtk_window_set_title(GTK_WINDOW(sMainWindow), newName);
}



/**
 * Rename a group
 */
static void popup_rename_group_cb()
{
	GError *err = NULL;
	GtkWidget *dialog = NULL;
	GtkWidget* gtkEntry = NULL;
	GtkWidget* gtkLabel = NULL;
	GtkWidget* table = NULL;
	GtkAttachOptions options = (GtkAttachOptions) (GTK_EXPAND | GTK_SHRINK | GTK_FILL);
	const gchar *newGroupName = NULL;
	
	
	// We can only rename groups!
	
	if (!sClickedNodeValid || sClickedNodeType != ITEMTYPE_GROUP) {
		goto EXITPOINT;
	}
	
	
	// Create a dialog box with a nicely-centered text entry widget
	
	dialog = gtk_dialog_new_with_buttons("Choose New Group Name", NULL, GTK_DIALOG_MODAL, GTK_STOCK_OK, GTK_RESPONSE_ACCEPT, GTK_STOCK_CANCEL, GTK_RESPONSE_REJECT, NULL);
	
	g_signal_connect(dialog, "response",  G_CALLBACK(gtk_widget_hide), dialog);
	gtk_container_border_width(GTK_CONTAINER(dialog), 0);
	
	table = gtk_table_new(1, 2, FALSE);
	
	gtkLabel = gtk_label_new("Enter new name of new group:");
	gtk_table_attach(GTK_TABLE(table), gtkLabel, 0, 1, 0, 1, options, options, 5, 5);
	
	gtkEntry = gtk_entry_new();
	g_signal_connect(GTK_OBJECT(gtkEntry), "activate", G_CALLBACK(entry_widget_activated_cb), dialog);
	gtk_table_attach(GTK_TABLE(table), gtkEntry, 1, 2, 0, 1, options, options, 5, 5);
	
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), table);
	
	gtk_widget_show_all (dialog);
	
	
	// Let the user enter a name or cancel the whole thing
	
	if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_REJECT) {
		goto EXITPOINT;
	}
	
	newGroupName = gtk_entry_get_text(GTK_ENTRY(gtkEntry));
	
	if (newGroupName == NULL || *newGroupName == '\0') {
		GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "Invalid group name");
		
		gtk_dialog_run(GTK_DIALOG(errDialog));
		
		gtk_widget_destroy(errDialog);
		
		goto EXITPOINT;
	}
	
	
	// Rename the group
	
	if (!set_tree_node_name(&sClickedNodeIter, newGroupName, &err)) {
		GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while renaming the group: %s", err->message);
		
		gtk_dialog_run(GTK_DIALOG(errDialog));
		
		gtk_widget_destroy(errDialog);
	}
	
	
EXITPOINT:
	
	// Destroying the dialog should also destroy the table, label, and entry widgets
	
	if (dialog) gtk_widget_destroy(dialog);
	
	if (err) g_error_free(err);
	
	// Do NOT free newGroupName, since that is owned by the GtkEntry widget!
}



/**
 * Ask the user for the name of a group and add it to the tree
 *
 * @param nodeIter is the node the group will be added to as a child; if NULL, then the group is added to the root of the tree
 */
static void ask_name_add_group(GtkTreeIter *nodeIter)
{
	GError *err = NULL;
	GtkWidget *dialog = NULL;
	GtkWidget* gtkEntry = NULL;
	GtkWidget* gtkLabel = NULL;
	GtkWidget* table = NULL;
	GtkAttachOptions options = (GtkAttachOptions) (GTK_EXPAND | GTK_SHRINK | GTK_FILL);
	const gchar *groupName = NULL;
	
	
	// Create a dialog box with a nicely-centered text entry widget
	
	dialog = gtk_dialog_new_with_buttons("Choose Group Name", NULL, GTK_DIALOG_MODAL, GTK_STOCK_OK, GTK_RESPONSE_ACCEPT, GTK_STOCK_CANCEL, GTK_RESPONSE_REJECT, NULL);
	
	g_signal_connect(dialog, "response",  G_CALLBACK(gtk_widget_hide), dialog);
	gtk_container_border_width(GTK_CONTAINER(dialog), 0);
	
	table = gtk_table_new(1, 2, FALSE);
	
	gtkLabel = gtk_label_new("Enter name of new group:");
	gtk_table_attach(GTK_TABLE(table), gtkLabel, 0, 1, 0, 1, options, options, 5, 5);
	
	gtkEntry = gtk_entry_new();
	g_signal_connect(GTK_OBJECT(gtkEntry), "activate", G_CALLBACK(entry_widget_activated_cb), dialog);
	gtk_table_attach(GTK_TABLE(table), gtkEntry, 1, 2, 0, 1, options, options, 5, 5);
	
	gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), table);
	
	gtk_widget_show_all (dialog);
	
	
	// Let the user enter a name or cancel the whole thing
	
	if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_REJECT) {
		goto EXITPOINT;
	}
	
	groupName = gtk_entry_get_text(GTK_ENTRY(gtkEntry));
	
	if (groupName == NULL || *groupName == '\0') {
		GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "Invalid group name");
		
		gtk_dialog_run(GTK_DIALOG(errDialog));
		
		gtk_widget_destroy(errDialog);
		
		goto EXITPOINT;
	}
	
	
	// Add the group
	
	if (!add_tree_group(nodeIter, ADD_CHILD, groupName, NULL, &err)) {
		GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while adding the group: %s", err->message);
		
		gtk_dialog_run(GTK_DIALOG(errDialog));
		
		gtk_widget_destroy(errDialog);
	}
	
	
EXITPOINT:
	
	// Destroying the dialog should also destroy the table, label, and entry widgets
	
	if (dialog) gtk_widget_destroy(dialog);
	
	if (err) g_error_free(err);
	
	// Do NOT free groupName, since that is owned by the GtkEntry widget!
}




/**
 * Callback for expand/collapse event of GtkTreeView
 *
 * @param treeView is not used
 * @param arg1 is not used
 * @param arg2 is not used
 * @param user_data is not used
 */
static void row_expand_or_collapse_cb(GtkTreeView *treeview, GtkTreeIter *arg1, GtkTreePath *arg2, gpointer user_data)
{
	// Set the project as dirty, since we save the state of expanded/collapsed rows
	
	set_project_dirty_status(TRUE);
}



/**
 * Callback for "Quit" menu item
 */
static void quit_menu_cb()
{
	prompt_user_to_save_project();
	
	if (!project_is_dirty()) {
		gtk_main_quit();
	}
}


/**
 * Callback for "About" menu item
 */
static void about_menu_cb()
{
	show_about_dialog();	
}


/**
 * Callback for "Usage" menu item
 */
static void usage_menu_cb()
{
	static char* helpText =	"To open or save projects, click the 'Open Project' or 'Save Project' buttons.  Project files are simple XML files, and may be easily modified using a text editor or other tool.\n\n"
							"Click the 'Add Files' or 'Add Group' buttons to add items to the project tree, then reorganize them via drag-and-drop.  Additional file and group operations are available via right-clicking.\n\n"
							"To open a file in SciTE, double-click the file item in the project tree, or highlight it and press return.";
	
	GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, helpText);
	
	if (dialog) {
		gtk_dialog_run(GTK_DIALOG(dialog));
		
		gtk_widget_destroy(dialog);
	}
}


/**
 * Callback for "Save Project" menu item
 */
static void saveproject_menu_cb()
{
	GError *err = NULL;
	
	if (!save_project(&err)) {
		GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while saving the project: %s", err->message);
		
		if (dialog) {
			gtk_dialog_run(GTK_DIALOG(dialog));
			
			gtk_widget_destroy(dialog);
		}
	}
	
	if (err) g_error_free(err);
}



/**
 * Callback for "Open Project" menu item
 */
static void openproject_menu_cb()
{
	GError *err = NULL;
	
	if (!load_project(NULL, &err)) {
		GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while saving the project: %s", err->message);
		
		if (dialog) {
			gtk_dialog_run(GTK_DIALOG(dialog));
			
			gtk_widget_destroy(dialog);
		}
	}
	
	if (err) g_error_free(err);
}



/**
 * Callback for "Create Group" menu item
 */
static void creategroup_menu_cb()
{
	ask_name_add_group(NULL);
}



/**
 * Callback for "Add File" menu item
 */
static void addfile_menu_cb()
{
	GError *err = NULL;
	
	if (!add_files_to_project(NULL, &err)) {
		GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while trying add files to the project: %s", err->message);
		
		if (dialog) {
			gtk_dialog_run(GTK_DIALOG(dialog));
			
			gtk_widget_destroy(dialog);
		}
	}
	
	if (err) g_error_free(err);
}



/**
 * Callback for menu manager to populate GUI widgets
 *
 * @param ui is the GtkUIManager
 * @param widget is the GtkWidget to add to the UI
 * @param container is the container to add widget to
 */
static void menu_add_widget_cb(GtkUIManager *ui, GtkWidget *widget, GtkContainer *container)
{
//~ 	printf("menu_add_widget_cb: Adding widget 0x%0lX to container 0x%0lX\n", (long) widget, (long) container);
	
	gtk_box_pack_start(GTK_BOX(container), widget, FALSE, FALSE, 0);
	gtk_widget_show(widget);
}



/**
 * Show the "About" dialog
 */

static void show_about_dialog() 
{
	gtk_show_about_dialog(NULL,	"name", "ScitePM", 
								"authors", sAuthors, 
								"version", sVersion, 
								"comments", "A project manager for Scite", 
								"copyright", "Copyright 2006 - Roy Wood", 
								"license",	sLicense,
								NULL);
}



/**
 * Show version
 */

void show_version()
{
	g_print("%s\n", sVersion);
}



/**
 * Show usage
 */

void show_usage()
{
	g_print("%s\n", sUsage);
}


//~ gboolean key_press_cb(GtkWidget *widget, GdkEventKey *event, gpointer userData)
//~ {
//~ 	switch (event->keyval) {
//~ 		case GDK_BackSpace: {
//~ 			g_print("key_press_cb: keyval = %d = GDK_BackSpace, hardware_keycode = %d", event->keyval, event->hardware_keycode);
//~ 			break;
//~ 		}
//~ 		
//~ 		case GDK_Delete: {
//~ 			g_print("key_press_cb: keyval = %d = GDK_Delete, hardware_keycode = %d", event->keyval, event->hardware_keycode);
//~ 			break;
//~ 		}
//~ 		
//~ 		case GDK_Insert: {
//~ 			g_print("key_press_cb: keyval = %d = GDK_Insert, hardware_keycode = %d", event->keyval, event->hardware_keycode);
//~ 			break;
//~ 		}
//~ 		
//~ 		default: {
//			g_print("key_press_cb: keyval = %d = '%c', hardware_keycode = %d", event->keyval, (char) event->keyval, event->hardware_keycode);
//~ 			
//~ 			return FALSE;
//~ 			
//~ 			break;
//~ 		}
//~ 	}
//~ 	
//~ 	if (event->state & GDK_SHIFT_MASK) g_print(", GDK_SHIFT_MASK");
//~ 	if (event->state & GDK_CONTROL_MASK) g_print(", GDK_CONTROL_MASK");
//~ 	if (event->state & GDK_MOD1_MASK) g_print(", GDK_MOD1_MASK");
//~ 	if (event->state & GDK_MOD2_MASK) g_print(", GDK_MOD2_MASK");
//~ 	if (event->state & GDK_MOD3_MASK) g_print(", GDK_MOD3_MASK");
//~ 	if (event->state & GDK_MOD4_MASK) g_print(", GDK_MOD4_MASK");
//~ 	if (event->state & GDK_MOD5_MASK) g_print(", GDK_MOD5_MASK");
//~ 	
//~ 	
//~ 	g_print("\n");
//~ 	
//~ 	return FALSE;
//~ }



//~ static gboolean tree_selection_cb(GtkTreeSelection *selection, GtkTreeModel *model, GtkTreePath *path, gboolean currentlySelected, gpointer data)
//~ {
//~ 	GtkTreeIter iter;
//~ 	gint nodeItemType;
//~ 	gint numSelected;
//~ 	gchar *pathString = NULL;
//~ 	gchar *nodeName = NULL;
//~ 	gboolean allowSelectionChange = TRUE;
//~ 	
//~ 	
//~ 	numSelected = gtk_tree_selection_count_selected_rows(selection);
//~ 	
//~ 	if (gtk_tree_model_get_iter(model, &iter, path)) {
//~ 		gtk_tree_model_get(model, &iter, COLUMN_ITEMTYPE, &nodeItemType, COLUMN_FILEPATH, &nodeName, -1);
//~ 	}
//~ 	
//~ 	pathString = gtk_tree_path_to_string(path);
//~ 	
//~ 	g_print("%s: Hit '%s', numSelected = %d, currentlySelected = %s\n", __func__, nodeName, numSelected, (currentlySelected) ? "true" : "false");
//~ 	
//~ 	if (nodeItemType == ITEMTYPE_GROUP && !currentlySelected && numSelected > 0) {
//~ 		allowSelectionChange = FALSE;
//~ 	}
//~ 	
//~ 	if (pathString) g_free(pathString);
//~ 	if (nodeName) g_free(nodeName);
//~ 	
//~ 	return allowSelectionChange;
//~ }
