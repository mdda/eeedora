#ifndef DRAG_DROP_H
#define DRAG_DROP_H


#include <gtk/gtk.h>
#include <glib.h>


struct TreeNodeStruct {
	gint nodeItemType;
	GtkTreePath *nodePath;
	GtkTreeIter nodeIter;
};

typedef struct TreeNodeStruct TreeNodeStruct;


struct TreeViewDragStruct {
	GtkTreeView *treeView;
	
	GtkTreeStore *treeStore;
	
	bool isLocalDrag;
	
	TreeNodeStruct *dragNodes;
	gint numDragNodes;
	
	GtkTreeViewDropPosition dropPositionHint;
};

typedef struct TreeViewDragStruct TreeViewDragStruct;


#define DND_STRING_TYPE		12345
#define DND_URI_TYPE		12346


// Callback for "drag-drop" event
extern gboolean drag_drop_cb(GtkWidget *widget, GdkDragContext *drag_context, gint x, gint y, guint time, gpointer user_data);

// Callback for "drag-motion" event
extern gboolean drag_motion_cb(GtkWidget *widget, GdkDragContext *drag_context, gint x, gint y, guint time, gpointer user_data);

// Callback for "drag-data-received" event
extern void drag_data_received_cb(GtkWidget *widget, GdkDragContext *dc, gint x, gint y, GtkSelectionData *selection_data, guint info, guint t, gpointer data);

// Callback for "drag-data-get" event
extern void drag_data_get_cb(GtkWidget *widget, GdkDragContext *dc, GtkSelectionData *selection_data, guint info, guint t, gpointer data);


#endif
