/* tree_manipulation.cc - GtkTreeView manipulation code for scitepm
 *
 *  Copyright 2006 Roy Wood
 *
 * scitepm is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * scitepm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with scitepm; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


#include "tree_manipulation.h"
#include "xml_processing.h"
#include "string_utils.h"
#include "gui.h"
#include "prefs.h"


#include <glib.h>
#include <gtk/gtk.h>

#include <string.h>
#include <sys/stat.h>


#define APP_SCITEPM_ERROR g_quark_from_static_string("APP_TREEMANIPULATION_ERROR")


// The types for each column in the tree datamodel

#define TYPE_ITEMTYPE			G_TYPE_UINT
#define TYPE_FILEPATH			G_TYPE_STRING
#define TYPE_FILENAME			G_TYPE_STRING
#define TYPE_FILESIZE			G_TYPE_STRING
#define TYPE_FONTWEIGHT			G_TYPE_INT
#define TYPE_FONTWEIGHTSET		G_TYPE_BOOLEAN
#define TYPE_STOCKITEM			G_TYPE_STRING

	


static GtkTreeStore *sTreeStore = NULL;
static bool sProjectIsDirty = FALSE;
static gchar *sProjectFilepath = NULL;
static gchar *sProjectDir = NULL;


// Predeclare static functions

static bool add_tree_filelist(GtkTreeIter *parentIter, GSList *fileList, GError **err);
static bool set_project_filepath(const gchar *filepath, GError **err);
static gboolean make_paths_relative(GtkTreeModel *model, GtkTreePath *path, GtkTreeIter *iter, gpointer data);



/**
 * Set the project filepath
 *
 * @param filepath is the new project filepath
 * @param err returns any error information
 */
static bool set_project_filepath(const gchar *filepath, GError **err)
{
	bool finalResult = FALSE;
	gchar *windowTitle = NULL;
	
	
	// Clear old data
	
	if (sProjectFilepath) g_free(sProjectFilepath);
	sProjectFilepath = NULL;
	
	if (sProjectDir) g_free(sProjectDir);
	sProjectDir = NULL;
	
	
	// Copy the filepath
	
	sProjectFilepath = g_strdup(filepath);
	
	
	// Extract the project's base directory
	
	if (sProjectFilepath) {
		gchar *finalSlash = NULL;
		
		if (sProjectFilepath[0] == '/') {
			sProjectDir = g_strdup(sProjectFilepath);
		}
		else {
			if (!relative_path_to_abs_path(sProjectFilepath, &sProjectDir, NULL, err)) {
				goto EXITPOINT;
			}
		}
		
		finalSlash = strrchr(sProjectDir, '/');
		
		if (finalSlash != NULL) {
			*finalSlash = '\0';
		};
		
//~ 		g_print("%s: sProjectDir = '%s'\n", __func__, sProjectDir);
	}
	
	
	windowTitle = g_strdup_printf("Scitepm - %s", sProjectFilepath);
	
	set_window_title(windowTitle);
	
	
	finalResult = true;
	
	
EXITPOINT:
	
	if (windowTitle) g_free(windowTitle);
	
	return finalResult;
}



/**
 * Get the project file directory.
 *
 * @return the project file's directory (pointer to static global-- do not modify!)
 */
const gchar* get_project_directory()
{
	return sProjectDir;
}



/**
 * Get the GTKTreeStore (evil, but necessary for setup_gui).
 *
 * @return the GtkTreeStore* for the project or NULL if a GtkTreeStore could not be allocate
 *
 * @param err returns any error information
 */
GtkTreeStore* get_treestore(GError **err)
{
	if (sTreeStore == NULL) {
		sTreeStore = gtk_tree_store_new(COLUMN_EOL, TYPE_ITEMTYPE, TYPE_FILEPATH, TYPE_FILENAME, TYPE_FILESIZE, TYPE_FONTWEIGHT, TYPE_FONTWEIGHTSET, TYPE_STOCKITEM);
		
		if (sTreeStore == NULL) {
			g_set_error(err, APP_SCITEPM_ERROR, -1, "%s: Could not create GtkTreeStore, gtk_tree_store_new() = NULL", __func__);
		}
	}
	
	return sTreeStore;
}



/**
 * Clear the GtkTreeStore.
 *
 * @param treeStore is the GtkTreeStore to add to
 */
void empty_tree(GtkTreeStore *treeStore)
{
	g_assert(treeStore != NULL);
	
	gtk_tree_store_clear(treeStore);
}



/**
 * Set the project "dirty" status and update the sensitivity of the "Save Project" button
 *
 * @param isDirty is the new "dirty" status for the project
 */
void set_project_dirty_status(bool isDirty)
{
	// Save the status
	
	sProjectIsDirty = isDirty;
	
	
	// Enable/disable the "Save Project" button as appropriate
	
	set_save_button_sensitivity(sProjectIsDirty);
}



/**
 * Get the "dirty" status of the project.
 *
 * @return TRUE if the project has been modified since loading; FALSE otherwise
 */
bool project_is_dirty()
{
	return sProjectIsDirty;
}



/**
 * If the current project is dirty, Prompt the user for a decision on whether to save it.
 * Note that if the user declines to save (i.e. chooses "No"), the project is marked as clean.
 */
void prompt_user_to_save_project()
{
	GtkWidget *dialog = NULL;
	gint tempResponseID = GTK_RESPONSE_CANCEL;
	
	
	// If the project is clean, things are simple
	
	if (!project_is_dirty()) {
		goto EXITPOINT;
	}
	
	
	// Project is dirty, so ask the user what to do about it
	
	dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_QUESTION, GTK_BUTTONS_NONE, "Save project changes?");
	gtk_dialog_add_button(GTK_DIALOG(dialog), GTK_STOCK_YES, GTK_RESPONSE_YES);
	gtk_dialog_add_button(GTK_DIALOG(dialog), GTK_STOCK_NO, GTK_RESPONSE_NO);
	gtk_dialog_add_button(GTK_DIALOG(dialog), GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL);
	
	tempResponseID = gtk_dialog_run(GTK_DIALOG(dialog));
	
	if (tempResponseID == GTK_RESPONSE_CANCEL) {
		goto EXITPOINT;
	}
	else if (tempResponseID == GTK_RESPONSE_NO) {
		// Yikes-- discard changes!
		set_project_dirty_status(FALSE);
	}
	else if (tempResponseID == GTK_RESPONSE_YES) {
		GError *err = NULL;
		GtkWidget *errDialog = NULL;
		
		if (!save_project(&err)) {
			errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while saving the project: %s", err->message);
			
			gtk_dialog_run(GTK_DIALOG(errDialog));
		}
		
		if (err) g_error_free(err);
		if (errDialog) gtk_widget_destroy(errDialog);
	}
	

EXITPOINT:
	
	if (dialog) gtk_widget_destroy(dialog);
}



/**
 * Save the project.
 *
 * @return FALSE if errors occurred during saving of the project; TRUE otherwise
 *
 * @param err returns any errors
 */
bool save_project(GError **err)
{
	GtkWidget *dialog = NULL;
	bool finalResult = FALSE;
	int resultID;
	
	
	// If the project does not have a name, pick one
	
	if (sProjectFilepath == NULL) {
		gchar *filename = NULL;
		GError *pathProcessErr = NULL;
		
		dialog = gtk_file_chooser_dialog_new("Save Project", NULL, GTK_FILE_CHOOSER_ACTION_SAVE, GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL, GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT, NULL);
		
//~ 		gtk_file_chooser_set_do_overwrite_confirmation(GTK_FILE_CHOOSER(dialog), TRUE);
		gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dialog), "untitled.xml");
		
		resultID = gtk_dialog_run(GTK_DIALOG(dialog));
		
		if (resultID != GTK_RESPONSE_ACCEPT) {
			finalResult = TRUE;
			goto EXITPOINT;
		}
		
		filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
		
		if (!set_project_filepath(filename, err)) {
			goto EXITPOINT;
		}
		
		g_free(filename);
		
		
		// Now that the project has a name, we have to make all the paths relative to it
		
		gtk_tree_model_foreach(GTK_TREE_MODEL(sTreeStore), make_paths_relative, &pathProcessErr);
		
		if (pathProcessErr) {
			GtkWidget *errDialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR, GTK_BUTTONS_OK, "An error occurred while making project file paths relative: %s", pathProcessErr->message);
			
			gtk_dialog_run(GTK_DIALOG(errDialog));
			
			gtk_widget_destroy(errDialog);
			
			g_error_free(pathProcessErr);
			
			goto EXITPOINT;
		}
	}
	
	
	// Try and save the project
	
	if (!save_tree_XML(GTK_TREE_MODEL(sTreeStore), sProjectFilepath, err)) {
		goto EXITPOINT;
	}
	
	set_project_dirty_status(FALSE);
	
	finalResult = TRUE;
	

EXITPOINT:
	
	if (dialog) gtk_widget_destroy(dialog);
	
	return finalResult;
}



/**
 * Make a node's path relative to the current sProjectDir (assumes the node's current path is relative 
 * to the current working dir)
 *
 * @param model is the GtkTreeModel
 * @param path is not used
 * @param iter is the GtkTreeIter to the node to process
 * @param data is a pointer to a GError in which any errors are returned
 */
static gboolean make_paths_relative(GtkTreeModel *model, GtkTreePath *path, GtkTreeIter *iter, gpointer data)
{
	gboolean finalResult = FALSE;
	GError **err = (GError **) data;
	gchar *absPath = NULL;
	gchar *origRelPath = NULL;
	gchar *finalRelPath = NULL;
	gint itemType;
	
	
	// Get the node type and content
	
	gtk_tree_model_get(model, iter, COLUMN_ITEMTYPE, &itemType, COLUMN_FILEPATH, &origRelPath, -1);
	
	
	if (itemType == ITEMTYPE_FILE && origRelPath && origRelPath[0] != '\0') {
		// The path is relative to the current working dir, so make it absolute
		
		if (!relative_path_to_abs_path(origRelPath, &absPath, NULL, err)) {
			finalResult = TRUE;
			goto EXITPOINT;
		}
		
		
		// Now make it relative to sProjectDir
		
		if (!abs_path_to_relative_path(absPath, &finalRelPath, sProjectDir, err)) {
			finalResult = TRUE;
			goto EXITPOINT;
		}
		
		
		// And stuff it back into the tree
		
		gtk_tree_store_set(GTK_TREE_STORE(model), iter, COLUMN_FILEPATH, finalRelPath, -1);
	}
	
	
EXITPOINT:
	
	if (origRelPath) g_free(origRelPath);
	if (absPath) g_free(absPath);
	if (finalRelPath) g_free(finalRelPath);
	
	return finalResult;
}




/**
 * Load a specified file or display a file selection dialog to allow a user to open a project.  
 * If a current project is open and dirty, then first prompt the user to save or discard changes.
 *
 * @return FALSE if errors occurred during loading of the project; TRUE otherwise
 *
 * @param projectPath is a path to a project to load; if NULL, then a file selection dialog is displayed
 * @param err returns any errors
 */
bool load_project(gchar *projectPath, GError **err)
{
	GtkWidget *dialog = NULL;
	bool finalResult = FALSE;
	gchar *filepath = NULL;
	GtkFileFilter* fileFilter = NULL;
	
	
	// Ensure the current project is saved
	
	prompt_user_to_save_project();
	
	if (project_is_dirty()) {
		finalResult = TRUE;
		goto EXITPOINT;
	}
	
	
	if (projectPath != NULL) {
		if (!load_parse_XML(sTreeStore, projectPath, err)) {
			goto EXITPOINT;
		}
		
		
		// Keep the project filepath for later reference when saving
		
		if (!set_project_filepath(projectPath, err)) {
			goto EXITPOINT;
		}
	}
	
	else {
		//  Pop up a file selection dialog and let the user choose a project file
		
		dialog = gtk_file_chooser_dialog_new("Load Project", NULL, GTK_FILE_CHOOSER_ACTION_OPEN, GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL, GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT, NULL);
		
		fileFilter = gtk_file_filter_new();
		gtk_file_filter_set_name(fileFilter, "Project Files (*.xml)");
		gtk_file_filter_add_pattern(fileFilter, "*.xml");
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), fileFilter);
		
		fileFilter = gtk_file_filter_new();
		gtk_file_filter_set_name(fileFilter, "All Files");
		gtk_file_filter_add_pattern(fileFilter, "*");
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), fileFilter);
		
		
		if (gtk_dialog_run(GTK_DIALOG (dialog)) != GTK_RESPONSE_ACCEPT) {
			finalResult = TRUE;
			goto EXITPOINT;
		}
		
		
		filepath = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
		
		if (!load_parse_XML(sTreeStore, filepath, err)) {
			goto EXITPOINT;
		}
		
		
		// Keep the project filepath for later reference when saving
		
		if (!set_project_filepath(filepath, err)) {
			goto EXITPOINT;
		}
	}
	
	
	set_project_dirty_status(FALSE);
	
	finalResult = TRUE;
	

EXITPOINT:
	
	if (dialog) gtk_widget_destroy(dialog);
	if (filepath) g_free(filepath);
	
	return finalResult;
}


void build_file_filter(int n, GtkFileFilter* fileFilter ) {
 switch(n) {
  case 0 : 
			gtk_file_filter_set_name(fileFilter, "C/C++ Files");
			gtk_file_filter_add_pattern(fileFilter, "*.c");
			gtk_file_filter_add_pattern(fileFilter, "*.cc");
			gtk_file_filter_add_pattern(fileFilter, "*.cpp");
			gtk_file_filter_add_pattern(fileFilter, "*.cxx");
			gtk_file_filter_add_pattern(fileFilter, "*.C");
			gtk_file_filter_add_pattern(fileFilter, "*.CC");
			gtk_file_filter_add_pattern(fileFilter, "*.CPP");
			gtk_file_filter_add_pattern(fileFilter, "*.CXX");
   break;
  case 1 : 
			gtk_file_filter_set_name(fileFilter, "LAMP Script Files");
			gtk_file_filter_add_pattern(fileFilter, "*.pm");
			gtk_file_filter_add_pattern(fileFilter, "*.pl");
			gtk_file_filter_add_pattern(fileFilter, "*.py");
			gtk_file_filter_add_pattern(fileFilter, "*.php*");
   break;
  case 2 : 
			gtk_file_filter_set_name(fileFilter, "Java* Files");
			gtk_file_filter_add_pattern(fileFilter, "*.js");
			gtk_file_filter_add_pattern(fileFilter, "*.java");
   break;
  case 3 : 
			gtk_file_filter_set_name(fileFilter, "HTML Files");
			gtk_file_filter_add_pattern(fileFilter, "*.html");
			gtk_file_filter_add_pattern(fileFilter, "*.htm");
			gtk_file_filter_add_pattern(fileFilter, "*.txt");
   break;
  default : 
			gtk_file_filter_set_name(fileFilter, "All Files");
			gtk_file_filter_add_pattern(fileFilter, "*");
   break;		
	}
 return;
}


/**
 * Display a file selection dialog to allow a user to add files to the current project.
 *
 * @return FALSE if errors occurred during loading of the project; TRUE otherwise
 *
 * @param parentIter is a pointer to the parent GtkTreeIter to add to, or NULL to add to the root of the tree
 * @param err returns any errors
 */
bool add_files_to_project(GtkTreeIter *parentIter, GError **err)
{
	bool finalResult = FALSE;
	GtkWidget *dialog = NULL;
	gchar *filepath = NULL;
	GtkFileFilter* fileFilter = NULL;
	GSList *fileList = NULL;
	
	
	// GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER 	
	// GTK_FILE_CHOOSER_ACTION_OPEN
	
	
	// Create the file selection dialog and add filters
	
	dialog = gtk_file_chooser_dialog_new ("Add Files", NULL, GTK_FILE_CHOOSER_ACTION_OPEN, GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL, GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT, NULL);
	
	
	gtk_file_chooser_set_select_multiple(GTK_FILE_CHOOSER(dialog), TRUE);
	
 // Select the choice from last time
 if(1) {  // gPrefs.last_file_filter>=0
		fileFilter = gtk_file_filter_new();
  build_file_filter(gPrefs.last_file_filter, fileFilter);
 	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), fileFilter);
	}
 for(int i=0; i<5;i++) {
		fileFilter = gtk_file_filter_new();
  build_file_filter(i, fileFilter);
 	gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), fileFilter);
	}

 // Select the files
	
	if (gtk_dialog_run(GTK_DIALOG (dialog)) != GTK_RESPONSE_ACCEPT) {
		finalResult = TRUE;
		goto EXITPOINT;
	}
	
 // Remember the choice, so that we can select it again
// fileFilter=gtk_file_chooser_get_filter(GTK_FILE_CHOOSER(dialog));

	// Process the list of chosen files
 fileList = gtk_file_chooser_get_filenames(GTK_FILE_CHOOSER(dialog));
	
	if (!add_tree_filelist(parentIter, fileList, err)) {
		goto EXITPOINT;
	}
	
	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (dialog) gtk_widget_destroy(dialog);
	if (filepath) g_free(filepath);
	
	if (fileList) {
		g_slist_foreach(fileList, (GFunc) g_free, NULL);
		g_slist_free(fileList);
	}
	
	return finalResult;
}



/**
 * Add a list of files to a GtkTreeStore.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param parentIter is a pointer to the parent GtkTreeIter to add to, or NULL to add to the root of the tree
 * @param fileList is the list of files to add to the tree
 * @param err returns any errors
 */
bool add_tree_filelist(GtkTreeIter *parentIter, GSList *fileList, GError **err)
{
	g_assert(sTreeStore != NULL);
	g_assert(fileList != NULL);
	
	bool finalResult = FALSE;
	GtkTreeIter newIter;
	GSList *listIter;
	gchar *absFilename;
	struct stat fileStat;
	
	
	listIter = fileList;
	
	for (listIter = fileList; listIter != NULL; listIter = g_slist_next(listIter)) {
		absFilename = (gchar *) (listIter->data);
		
		if (!absFilename) {
			continue;
		}
		
		if (stat(absFilename, &fileStat) != 0 || !S_ISREG(fileStat.st_mode)) {
			continue;
		}
		
		if (listIter == fileList) {
			add_tree_file(parentIter, ADD_CHILD, absFilename, &newIter, true, err);
		}
		else {
			add_tree_file(&newIter, ADD_AFTER, absFilename, &newIter, true, err);
		}
	}
	
	set_project_dirty_status(TRUE);
	
	finalResult = TRUE;
	
	return finalResult;
}



/**
 * Add a group node to an existing parent node, or to the root of the GtkTreeStore.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param parentIter is a pointer to the parent GtkTreeIter to add to, or NULL to add to the root of the tree
 * @param position indicates the relative position to add the file node
 * @param newIter returns the new GtkTreeIter (pass NULL if this result is not needed)
 * @param groupname is the name of the group to add to the tree
 * @param err returns any errors
 */
bool add_tree_group(GtkTreeIter *parentIter, NodePosition position, const gchar* groupname, GtkTreeIter *newIter, GError **err)
{
	g_assert(sTreeStore != NULL);
	g_assert(groupname != NULL);
	
	bool finalResult = FALSE;
	GtkTreeIter iter;
	
	
	// Append to root, or before/after/within an existing node?
	
	if (parentIter == NULL) {
		gtk_tree_store_insert_before(sTreeStore, &iter, NULL, NULL);
	}
	else if (position == ADD_BEFORE) {
		gtk_tree_store_insert_before(sTreeStore, &iter, NULL, parentIter);
	}
	else if (position == ADD_AFTER) {
		gtk_tree_store_insert_after(sTreeStore, &iter, NULL, parentIter);
	}
	else if (position == ADD_CHILD) {
		gtk_tree_store_append(sTreeStore, &iter, parentIter);
	}
	
	if (newIter) {
		*newIter = iter;
	}
	
	// Add the group node
	
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_ITEMTYPE, ITEMTYPE_GROUP, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FILENAME, groupname, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FILEPATH, groupname, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FONTWEIGHT, PANGO_WEIGHT_BOLD, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FONTWEIGHTSET, TRUE, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_STOCKITEM, "gtk-directory", -1);
	
	
	set_project_dirty_status(TRUE);
	
	finalResult = TRUE;
	
	return finalResult;
}



/**
 * Add a file node to an existing parent node, or to the root of the GtkTreeStore.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param currentIter is a pointer to the parent GtkTreeIter to add to, or NULL to add to the root of the tree
 * @param position indicates the relative position to add the file node
 * @param filepath is the filepath to add to the tree
 * @param newIter returns the GtkTreeIter that refers to the new node
 * @param makeRelative indicates whether the filepath should be converted to a relative path before being added to the tree
 * @param err returns any errors
 */
bool add_tree_file(GtkTreeIter *currentIter, NodePosition position, const gchar* filepath, GtkTreeIter *newIter, bool makeRelative, GError **err)
{
	g_assert(sTreeStore != NULL);
	g_assert(filepath != NULL);
	g_assert(position == ADD_BEFORE || position == ADD_AFTER || position == ADD_CHILD);
	
	bool finalResult = FALSE;
	GtkTreeIter iter;
	const gchar* fileName = NULL;
	gchar *relFilename = NULL;
	
	
	// Append to root, or before/after/within an existing node?
	
	if (currentIter == NULL) {
		gtk_tree_store_insert_before(sTreeStore, &iter, NULL, NULL);
	}
	else if (position == ADD_BEFORE) {
		gtk_tree_store_insert_before(sTreeStore, &iter, NULL, currentIter);
	}
	else if (position == ADD_AFTER) {
		gtk_tree_store_insert_after(sTreeStore, &iter, NULL, currentIter);
	}
	else if (position == ADD_CHILD) {
		gtk_tree_store_insert_after(sTreeStore, &iter, currentIter, NULL);
	}
	
	
	// Make the filename relative?
	
	if (!makeRelative) {
		relFilename = g_strdup(filepath);
	}
	else if (!abs_path_to_relative_path(filepath, &relFilename, sProjectDir, err)) {
		goto EXITPOINT;
	}
	
	
	// Extract filename from filepath
	
	fileName = strrchr(filepath, '/');
	
	if (fileName != NULL) {
		++fileName;
	}
	
	if (fileName == NULL || strlen(fileName) <= 0) {
		fileName = filepath;
	}
	
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_ITEMTYPE, ITEMTYPE_FILE, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FILEPATH, relFilename, -1);
	gtk_tree_store_set(sTreeStore, &iter, COLUMN_FILENAME, fileName, -1);
	
	if (newIter) {
		*newIter = iter;
	}
	
	set_project_dirty_status(TRUE);
	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (relFilename) g_free(relFilename);
	
	return finalResult;
}



/**
 * Remove a node from the GtkTreeStore.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param iter references the node to remove
 * @param err returns any errors
 */
extern bool remove_tree_node(GtkTreeIter *iter, GError **err)
{
	gtk_tree_store_remove(sTreeStore, iter);
	
	set_project_dirty_status(TRUE);
	
	return TRUE;
}



/**
 * Set the contents of a node.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param iter is a reference to the node to change
 * @param newContents is the new content for the node
 * @param err returns any errors
 */
bool set_tree_node_name(GtkTreeIter *iter, const gchar *newContents, GError **err)
{
	g_assert(iter != NULL);
	g_assert(newContents != NULL);
	
	gtk_tree_store_set(sTreeStore, iter, COLUMN_FILENAME, newContents, -1);
	
	set_project_dirty_status(TRUE);
	
	return TRUE;
}



/**
 * Copy a node (and children) within the tree.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param srcIter is a reference to the node to move
 * @param dstIter is a reference to the destination node; NULL if the root of the tree
 * @param newIter returns the iter of the copy
 * @param position indicates where copy the node, relative to srcIter
 * @param err returns any errors
 */
bool copy_tree_node(GtkTreeIter *srcIter, GtkTreeIter *dstIter, NodePosition position, GtkTreeIter *newIter, GError **err)
{
	g_assert(srcIter != NULL);
	g_assert(position == ADD_BEFORE || position == ADD_AFTER || position == ADD_CHILD);
	
	gchar *nodeContents = NULL;
	bool finalResult = FALSE;
	gint itemType;
	GtkTreeIter srcChildIter;
	GtkTreeIter dstChildIter;
	GtkTreePath *srcPath = NULL;
	GtkTreePath *newPath = NULL;
	bool groupIsExpanded = FALSE;
	GtkTreeIter newGroupIter;
	
	
	// Get the node type and content
	
	gtk_tree_model_get(GTK_TREE_MODEL(sTreeStore), srcIter, COLUMN_ITEMTYPE, &itemType, COLUMN_FILEPATH, &nodeContents, -1);
	
	
	// Add a file or group?
	
	if (itemType == ITEMTYPE_FILE) {
		if (!add_tree_file(dstIter, position, nodeContents, newIter, false, err)) {
			goto EXITPOINT;
		}
	}
	else {
		// Is the source group currently expanded?
		
		srcPath = gtk_tree_model_get_path(GTK_TREE_MODEL(sTreeStore), srcIter);
		groupIsExpanded = tree_row_is_expanded(srcPath);
		
		
		// Add the copy of the group
		
		if (!add_tree_group(dstIter, position, nodeContents, &newGroupIter, err)) {
			goto EXITPOINT;
		}
		
		if (newIter) {
			*newIter = newGroupIter;
		}
		
		
		// Recursively copy the group's contents, too
		
		if (gtk_tree_model_iter_children(GTK_TREE_MODEL(sTreeStore), &srcChildIter, srcIter)) {
			// Copy the first child as ADD_CHILD
			
			if (!copy_tree_node(&srcChildIter, &newGroupIter, ADD_CHILD, &dstChildIter, err)) {
				goto EXITPOINT;
			}
			
			// Copy each subsequent child ADD_AFTER its prior sibling
			
			while (gtk_tree_model_iter_next(GTK_TREE_MODEL(sTreeStore), &srcChildIter)) {
				if (!copy_tree_node(&srcChildIter, &dstChildIter, ADD_AFTER, &dstChildIter, err)) {
					goto EXITPOINT;
				}
			}
		}
		
		// Expand the new group?
		
		if (groupIsExpanded) {
			newPath = gtk_tree_model_get_path(GTK_TREE_MODEL(sTreeStore), &newGroupIter);
			expand_tree_row(newPath, FALSE);
		}
	}
	
	set_project_dirty_status(TRUE);
	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (nodeContents) g_free(nodeContents);
	if (srcPath) gtk_tree_path_free(srcPath);
	if (newPath) gtk_tree_path_free(newPath);
	
	return finalResult;
}
