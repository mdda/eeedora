/* xml_processing.cc - XML processing support for scitepm
 *
 *  Copyright 2006 Roy Wood
 *
 * scitepm is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * scitepm is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with scitepm; see the file COPYING.LIB.  If not,
 * write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */


#include "xml_processing.h"
#include "gfileutils_local.h"
#include "string_utils.h"
#include "tree_manipulation.h"
#include "gui.h"


#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gstdio.h>

#include <string.h>


// This module loads or saves an xml file, marshalling or unmarshalling data to/from a GtkTreeStore, 
// including adding nodes to the tree.
// The xml file is assumed to consist of <file> elements and/or <group> elements.
// The pathnames of the files are contained in the text of the <file> elements, and the name of
// the group elements are contained in a "name" attribute of the <group> element.



// Forward declare the static functions in the module

static void start_element_cb(GMarkupParseContext *context, const gchar *element_name, const gchar **attribute_names, const gchar **attribute_values, gpointer user_data, GError **error);
static void end_element_cb(GMarkupParseContext *context, const gchar *element_name, gpointer user_data, GError **error);
static void text_cb(GMarkupParseContext *context, const gchar *text, gsize text_len, gpointer user_data, GError **error);
static void passthrough_cb(GMarkupParseContext *context, const gchar *passthrough_text, gsize text_len, gpointer user_data, GError **error);
static void error_cb(GMarkupParseContext *context, GError *error, gpointer user_data);

static bool marshal_subtree(GtkTreeModel *treeModel, GtkTreeIter *currentIter, gchar **xmlString, GError **err);



// ParseStruct is used to store the state of a parsing operation

struct ParseStruct {
	GtkTreeIter currentIter; // reference to the current group node
	bool prevFileIterValid; // flag indicating whether the prevFileIter is valid
	GtkTreeIter prevFileIter; // reference to the previous file node
	int depth; // depth of parse
	bool inFileElement; // flag indicating whether we are processing a file node
	GtkTreeStore *treeStore; // pointer to the GtkTreeStore we are populating
	bool *expandFlags; // an array of flags used to track whether the group nodes should be expanded (must be done AFTER adding child nodes-- argh!)
};

typedef struct ParseStruct ParseStruct;





/**
 * Handle the start of an element during parsing.
 *
 * @param context is the parse context
 * @param element_name is the name of the node being closed
 * @param attribute_names is the list of attribute names
 * @param attribute_values is the list of attribute values
 * @param user_data is a pointer to the ParseStruct struct used to store state info during parsing
 * @param error is the error object
 */
static void start_element_cb(GMarkupParseContext *context, const gchar *element_name, const gchar **attribute_names, const gchar **attribute_values, gpointer user_data, GError **error)
{
	ParseStruct *parseStruct = (ParseStruct *) user_data;
	
	g_assert(parseStruct != NULL);
	g_assert(parseStruct->treeStore != NULL);
	
	
	// Is it a "group" element?
	
	if (strcmp(element_name, "group") == 0) {
		// Extract the "name" or "is_expanded" attribute, if they exist
		
		const gchar *groupname = "<anonymous>";
		bool expanded = FALSE;
		
		for (int i = 0; attribute_names[i] != NULL; ++i) {
			if (strcmp(attribute_names[i], "name") == 0) {
				groupname = attribute_values[i];
			}
			else if (strcmp(attribute_names[i], "expanded") == 0) {
				if (strcmp(attribute_values[i], "TRUE") == 0 || strcmp(attribute_values[i], "true") == 0) {
					expanded = TRUE;
				}
			}
		}
		
		
		// Add to the root of the tree, or as a child of an existing group?
		
		if (parseStruct->depth <= 0) {
			add_tree_group(NULL, ADD_CHILD, groupname, &(parseStruct->currentIter), error);
		}
		else {
			add_tree_group(&(parseStruct->currentIter), ADD_CHILD, groupname, &(parseStruct->currentIter), error);
		}
		
		
		// Increment the depth
		
		parseStruct->depth++;
		
		
		// Keep the expanded state so we can apply it after we've added any children of this node
		
		parseStruct->expandFlags = (bool *) g_realloc(parseStruct->expandFlags, parseStruct->depth);
		
		parseStruct->expandFlags[parseStruct->depth] = expanded;
		
		
		// Note that prevFileIter is not valid
		
		parseStruct->prevFileIterValid = FALSE;
	}
	else if (strcmp(element_name, "file") == 0) {
		// Note that we're now in a file element, so text_cb() will extract and use subsequent text
		
		parseStruct->inFileElement = true;
	}
}



/**
 * Handle the end of an element during parsing.
 *
 * @param context is the parse context
 * @param element_name is the name of the node being closed
 * @param user_data is a pointer to the ParseStruct struct used to store state info during parsing
 * @param error is the error object
 */
static void end_element_cb(GMarkupParseContext *context, const gchar *element_name, gpointer user_data, GError **error)
{
	ParseStruct *parseStruct = (ParseStruct *) user_data;
	
	g_assert(parseStruct != NULL);
	g_assert(parseStruct->treeStore != NULL);
	
	
	if (strcmp(element_name, "group") == 0) {
		// Now that all children have been added, should we expand the node?
		
		if (parseStruct->expandFlags && parseStruct->expandFlags[parseStruct->depth]) {
			GtkTreePath *path = gtk_tree_model_get_path(GTK_TREE_MODEL(parseStruct->treeStore), &(parseStruct->currentIter));
			
			if (path != NULL) {
				expand_tree_row(path, FALSE);
				
				gtk_tree_path_free(path);
			}
		}
		
		
		
		// End of a group node, so decrement the depth and step back up the tree one level
		
		if (parseStruct->depth > 0) {
			GtkTreeIter parentIter;
			
			
			parseStruct->depth -= 1;
			
			if (gtk_tree_model_iter_parent(GTK_TREE_MODEL(parseStruct->treeStore), &parentIter, &(parseStruct->currentIter))) {
				parseStruct->currentIter = parentIter;
			}
			else {
				// Should never happen, but....
				
				parseStruct->depth = 0;
			}
		}
	}
	else if (strcmp(element_name, "file") == 0) {
		parseStruct->inFileElement = false;
	}
}



/**
 * Handle text of an element data during parsing.
 *
 * @param context is the parse context
 * @param passthrough_text is the passthrough data (comments, etc.)
 * @param text_len is the length of the passthrough data
 * @param user_data is a pointer to the ParseStruct struct used to store state info during parsing
 * @param error is the error object
 */
static void text_cb(GMarkupParseContext *context, const gchar *text, gsize text_len, gpointer user_data, GError **error)
{
	ParseStruct *parseStruct = (ParseStruct *) user_data;
	
	g_assert(parseStruct != NULL);
	g_assert(parseStruct->treeStore != NULL);
	
//	if (text == NULL && strlen(text) <= 0 || text[0] == '\n' || !parseStruct->inFileElement) {
	if (text == NULL || strlen(text) <= 0 || text[0] == '\n' || !parseStruct->inFileElement) {
		return;
	}
	
	
	// Append to root or an existing node?
	
	if (parseStruct->depth <= 0) {
		if (parseStruct->prevFileIterValid) {
			add_tree_file(&(parseStruct->prevFileIter), ADD_AFTER, text, &(parseStruct->prevFileIter), false, error);
		}
		else {
			add_tree_file(NULL, ADD_CHILD, text, &(parseStruct->prevFileIter), false, error);
		}
	}
	else {
		if (parseStruct->prevFileIterValid) {
			add_tree_file(&(parseStruct->prevFileIter), ADD_AFTER, text, &(parseStruct->prevFileIter), false, error);
		}
		else {
			add_tree_file(&(parseStruct->currentIter), ADD_CHILD, text, &(parseStruct->prevFileIter), false, error);
		}
	}
	
	parseStruct->prevFileIterValid = TRUE;
}



/**
 * Handle passthrough data during parsing.
 *
 * @param context is the parse context
 * @param passthrough_text is the passthrough data (comments, etc.)
 * @param text_len is the length of the passthrough data
 * @param user_data is a pointer to the ParseStruct struct used to store state info during parsing
 * @param error is the error object
 */
static void passthrough_cb(GMarkupParseContext *context, const gchar *passthrough_text, gsize text_len, gpointer user_data, GError **error)
{
	// Don't care right now....
}


/**
 * Handle errors during parsing.
 *
 * @param context is the parse context
 * @param error is the error object
 * @param user_data is a pointer to the ParseStruct struct used to store state info during parsing
 */
static void error_cb(GMarkupParseContext *context, GError *error, gpointer user_data)
{
	// Don't care right now....
}


/**
 * Parse an XML file and populate a GtkTreeStore with the extracted data.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param treeStore is the GtkTreeStore to populate
 * @param filepath is the path to the file to read and parse
 * @param err returns any errors
 */
bool load_parse_XML(GtkTreeStore *treeStore, const char *filepath, GError **err)
{
	g_assert(treeStore != NULL);
	g_assert(filepath != NULL);
	
	bool finalResult = FALSE;
	GMarkupParseContext *parseContext = NULL;
	GMarkupParser parser = { start_element_cb, end_element_cb, text_cb, passthrough_cb, error_cb };
	gsize xmlSize = 0;
	gchar *xml = NULL;
	ParseStruct parseStruct;

	
	// Read in the file
	
	if (!g_file_get_contents(filepath, &xml, &xmlSize, err)) {
		goto EXITPOINT;
	}
	
	
	// Clear any data that might already be in the tree
	
	gtk_tree_store_clear(treeStore);
	
	
	// Create an XML parser
	
	parseStruct.depth = 0;
	parseStruct.prevFileIterValid = FALSE;
	parseStruct.inFileElement = FALSE;
	parseStruct.treeStore = treeStore;
	parseStruct.expandFlags = NULL;
	
	parseContext = g_markup_parse_context_new(&parser, (GMarkupParseFlags) 0, &parseStruct, NULL);
	
	
	// Parse the data....
	
	if (!g_markup_parse_context_parse(parseContext, (char *) xml, xmlSize, err)) {
		goto EXITPOINT;
	}
	
	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (parseContext) g_markup_parse_context_free(parseContext);
	if (xml) g_free(xml);
	if (parseStruct.expandFlags) g_free(parseStruct.expandFlags);
	
	if (!finalResult) {
		// A parsing error occurred, so junk it all
		gtk_tree_store_clear(treeStore);
	}
	
	return finalResult;
}



/**
 * Marshal a subtree of a GtkTreeModel by appending its textual representation to an input string.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 *
 * @param treeModel is the GtkTreeModel
 * @param subtreeIter is the iterator reference to the subtree to process
 * @param xmlString returns the marshaled output; the text is appended to this string
 * @param err returns any errors
 */
static bool marshal_subtree(GtkTreeModel *treeModel, GtkTreeIter *subtreeIter, gchar **xmlString, GError **err)
{
	g_assert(treeModel != NULL);
	g_assert(subtreeIter != NULL);
	g_assert(xmlString != NULL);
	
	bool finalResult = FALSE;
	gint itemType;
	gchar *filepathString = NULL;
	gchar *tmpXML = NULL;
	gchar *indentString = NULL;
	gint depth;
	
	
	// Set up indent
	
	depth = gtk_tree_store_iter_depth(GTK_TREE_STORE(treeModel), subtreeIter) + 1;
	
	indentString = g_strnfill(depth, '\t');
	
	
	// Get relevant data for current node
	
	gtk_tree_model_get(treeModel, subtreeIter, COLUMN_FILEPATH, &filepathString, COLUMN_ITEMTYPE, &itemType, -1);
	
	if (itemType == ITEMTYPE_FILE) {
		// Write out a simple file node
		
		tmpXML = g_markup_printf_escaped("%s<file>%s</file>\n", indentString, filepathString);
		
		if (!str_append(xmlString, tmpXML, err)) {
			goto EXITPOINT;
		}
	}
	else if (itemType == ITEMTYPE_GROUP) {
		// This node is a group, so append a <group name='foo'> tag and recurse into the node
		
		bool groupIsExpanded = FALSE;
		GtkTreePath *path = gtk_tree_model_get_path(treeModel, subtreeIter);
		
		if (path != NULL) {
			groupIsExpanded = tree_row_is_expanded(path);
			
			gtk_tree_path_free(path);
		}
		
		
		tmpXML = g_markup_printf_escaped("%s<group name='%s' expanded='%s'>\n", indentString, filepathString, groupIsExpanded ? "TRUE" : "FALSE");
		
		if (!str_append(xmlString, tmpXML, err)) {
			goto EXITPOINT;
		}
		
		GtkTreeIter childIter;
		
		if (gtk_tree_model_iter_children(treeModel, &childIter, subtreeIter)) {
			do {
				if (!marshal_subtree(treeModel, &childIter, xmlString, err)) {
					goto EXITPOINT;
				}
			} while (gtk_tree_model_iter_next(treeModel, &childIter));
		}
		
		// Don't forget to append the close tag
		
		if (!str_append(xmlString, indentString, err) || !str_append(xmlString, "</group>\n", err)) {
			goto EXITPOINT;
		}
	}
	
	finalResult = TRUE;
	

EXITPOINT:
	
	if (filepathString) g_free(filepathString);
	if (tmpXML) g_free(tmpXML);
	if (indentString) g_free(indentString);
	
	return finalResult;
}



/**
 * Save the contents of a GtkTreeModel to a file.
 *
 * @return TRUE on success, FALSE on failure (further details returned in err)
 * 
 * @param treeModel is the GtkTreeModel to save; the COLUMN_FILEPATH items are extracted and saved
 * @param filepath is the pathname for the target file
 * @param err returns any errors
 */
bool save_tree_XML(GtkTreeModel *treeModel, const gchar *filepath, GError **err)
{
	g_assert(treeModel != NULL);
	g_assert(filepath != NULL);
	
	bool finalResult = FALSE;
	GtkTreeIter iter;
	gchar *xmlString = NULL;
	
	
	// Add <root> of document
	
	if (!str_append(&xmlString, "<root>\n", err)) {
		goto EXITPOINT;
	}
	
	
	// Iterate over root level of tree
	
	if (gtk_tree_model_get_iter_first(treeModel, &iter)) {
		do {
			if (!marshal_subtree(treeModel, &iter, &xmlString, err)) {
				goto EXITPOINT;
			}
		} while (gtk_tree_model_iter_next(treeModel, &iter));
	}
	
	// Close <root>
	
	if (!str_append(&xmlString, "</root>\n", err)) {
		goto EXITPOINT;
	}
	
//~ 	g_print(xmlString);
	
	// Write out file
	
	if (!g_file_set_contents(filepath, xmlString, -1, err)) {
		goto EXITPOINT;
	}
	

	
	finalResult = TRUE;
	
	
EXITPOINT:
	
	if (xmlString) g_free(xmlString);
	
	return finalResult;
}
