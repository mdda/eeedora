#ifndef SCITE_UTILS_H
#define SCITE_UTILS_H


#include <glib.h>



// Fork a child process and launch Scite from it
bool launch_scite(gchar *sciteExecutableName, GError **err);


// Send a command to Scite, launching Scite if necessary
bool send_scite_command(gchar *command, GError **err);


// Determine whether Scite is currently launched and the communication pipes are open
bool scite_ready();


// Activate the SciTE window (i.e. bring it the front)
bool activate_scite(GError **err);


#endif
