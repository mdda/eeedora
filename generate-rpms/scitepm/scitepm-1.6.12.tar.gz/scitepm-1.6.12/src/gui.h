#ifndef GLOBALS_H
#define GLOBALS_H

#include <gtk/gtk.h>

// Initialize the GUI
bool setup_gui(GError **err);

// Enable/Disable the "Save Project" button
void set_save_button_sensitivity(bool enabled);

// Set the window title
void set_window_title(const gchar *newName);

// Is a given row expanded?
bool tree_row_is_expanded(GtkTreePath *path);

// Expand a row
void expand_tree_row(GtkTreePath *path, bool expandChildren);

// Show app version
void show_version();

// Show app usage
void show_usage();

void get_dimensions(gint *left, gint *top, gint *width, gint *height);

#endif

