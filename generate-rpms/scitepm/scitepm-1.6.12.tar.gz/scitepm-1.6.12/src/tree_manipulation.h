#ifndef TREE_MANIPULATION_H
#define TREE_MANIPULATION_H

#include <gtk/gtk.h>


// Node relative-position indicators

enum NodePosition {
	ADD_BEFORE,
	ADD_AFTER,
	ADD_CHILD
};


// Mnemonic identifiers for the columns in the GtkTreeStore

enum { 
	COLUMN_ITEMTYPE = 0,
	COLUMN_FILEPATH, 
	COLUMN_FILENAME, 
	COLUMN_FILESIZE, 
	COLUMN_FONTWEIGHT,
	COLUMN_FONTWEIGHTSET,
	COLUMN_STOCKITEM,
	COLUMN_EOL
};


// The type of each row in the tree datamodel

enum {
	ITEMTYPE_GROUP,
	ITEMTYPE_FILE
};



// Get the GTKTreeStore
GtkTreeStore* get_treestore(GError **err);

// Get the project file directory
const gchar* get_project_directory();

// Clear the tree
extern void empty_tree(GtkTreeStore *treeStore);

// Mark the project as dirty or clean (i.e. modified and in need of saving)
void set_project_dirty_status(bool isDirty);

// Get the status of the project
bool project_is_dirty();

// Prompting the user to save the project if it is dirty
void prompt_user_to_save_project();

// Save the current project, or pop up an error dialog if something bad happened
bool save_project(GError **err);

// Allow user to select a project file to load (save current project first, if appropriate)
bool load_project(gchar *projectPath, GError **err);

// Allow user to select and add files to the project
bool add_files_to_project(GtkTreeIter *parentIter, GError **err);

// Add a file node to a GtkTreeModel
extern bool add_tree_file(GtkTreeIter *currentIter, NodePosition position, const gchar* filepath, GtkTreeIter *newIter, bool makeRelative, GError **err);

// Add a group node to a GtkTreeModel
extern bool add_tree_group(GtkTreeIter *parentIter, NodePosition position, const gchar* groupname, GtkTreeIter *newIter, GError **err);

// Remove a node from a GtkTreeModel
extern bool remove_tree_node(GtkTreeIter *iter, GError **err);

// Remove a node from a GtkTreeModel
extern bool set_tree_node_name(GtkTreeIter *iter, const gchar *newContents, GError **err);

// Copy a node in the tree (including children)
bool copy_tree_node(GtkTreeIter *srcIter, GtkTreeIter *dstIter, NodePosition position, GtkTreeIter *newIter, GError **err);

#endif
