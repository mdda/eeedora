#ifndef PREFS_H
#define PREFS_H


// #include <gtk/gtk.h>

typedef struct {
	int lhs;
	int width, height;
 int verbosity;
 int last_file_filter;
//	int desktop;
} scitepm_prefs;

extern scitepm_prefs gPrefs;

void init_prefs();


#endif
