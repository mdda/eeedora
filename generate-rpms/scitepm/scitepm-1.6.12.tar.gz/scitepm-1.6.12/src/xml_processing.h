#ifndef XML_PROCESSING_H
#define XML_PROCESSING_H

#include <gtk/gtk.h>
#include <glib.h>


// Save the contents of a GtkTreeModel into a file
extern bool save_tree_XML(GtkTreeModel *treeModel, const gchar *filepath, GError **err);

// Load and parse an XML file, populating a GtkTreeStore with the data
extern bool load_parse_XML(GtkTreeStore *treeStore, const char *filePath, GError **err);

#endif

