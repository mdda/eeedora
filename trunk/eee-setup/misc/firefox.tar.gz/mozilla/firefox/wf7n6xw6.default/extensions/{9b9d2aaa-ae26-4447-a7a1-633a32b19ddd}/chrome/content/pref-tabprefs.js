/*
 * pref-tabprefs.js
 *
 * contains all of the preference dialog handling code
 *
 */

/**
 * @brief Disables/enables a UI element associated with a preference element.
 *
 * This function is designed to enable or disable a UI element when a certain
 * preference element changes value.
 *
 * @param uiElement		The UI element to be enabled/disabled.
 * @param prefElement		The preference element whose state determines
 *				the state of the UI element.
 * @returns			true if the preference was true and the UI was
 *				not disabled, false if the preference was
 *				not true and the UI was disabled.
 *
 */
function TBP_setDependentUI(uiElement, prefElement)
{
	var element = document.getElementById(uiElement);
	var preference = document.getElementById(prefElement);

	if (preference.value) {
		element.disabled = false;
		return true;
	}
	else {
		element.disabled = true;
		return false;
	}
	return true;
}
