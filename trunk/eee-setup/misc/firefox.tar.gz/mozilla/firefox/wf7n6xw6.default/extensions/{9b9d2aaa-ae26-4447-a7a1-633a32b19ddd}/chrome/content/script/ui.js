/*
 * tpscript/ui.js
 *
 * this contains all of the code responsible for modifying the Firefox
 * UI, including the UI provided by TBP
 *
 */

var gPref = 	        NS_CC["@mozilla.org/preferences-service;1"].
	    	        getService(NS_CI.nsIPrefBranch); 

var __UIsetup;

/*
 * observe some of TBP's preferences and do something when they change
 *
 */
var TBP_prefObserver = {
	_windowManager: NS_CC["@mozilla.org/appshell/window-mediator;1"]
		          .getService(NS_CI.nsIWindowMediator),

	/**
	 * @brief Observe changes in certain preferences.
	 *
	 * @param aSubject		An nsISupports, capable of QIing to nsIPrefBranch.
	 * @param aTopic		A character string, equal to "nsPref:changed"
	 * @param aData			A character string equal to the name of the
	 *				preference whose change fired the observer.
	 * @return			Nothing.
	 *
	 */
	observe: function(aSubject, aTopic, aData)
	{
		if (aTopic != "nsPref:changed") return;
		var pref = aSubject.QueryInterface(NS_CI.nsIPrefBranch);
		switch (aData) {
		 	case "extensions.tabprefs.lockAllTabs" : {
				this.lockAllTabs(pref.getBoolPref(aData));
			        break;
			}
			case "extensions.tabprefs.reverseTab" : {
				this.reverseTabBar(pref.getBoolPref(aData));
				break;
			}
			case "extensions.tabprefs.showTabButton" : {
				this.showTabButton(pref.getBoolPref(aData));
				break;
			}
		}
		return;
	},

	/**
	 * @brief Lock all tabs.
	 *
	 * This function iterates over all open windows and locks each tab open within
	 * the window. It additionally sets the lockedBrowser attribute on each individual
	 * tabbrowser to indicate that all of its tabs are locked.
	 *
	 * @param value			A Boolean value. If true, the function will lock all tabs
	 *		        	within the current window. If false, it will unlock them.
	 * @returns	        	true
	 *
	 */
	lockAllTabs: function(value)
	{
		var tBrowser, tabArray, browser, i;
		var _windows = this._windowManager.getEnumerator(BROWSER_WINDOWTYPE);

		while (_windows.hasMoreElements()) {
			tBrowser = _windows.getNext().getBrowser();
			tabArray = tBrowser.mTabs;
			for (i = 0; i < tabArray.length; ++i) {
				tabArray[i].tabLocked = value;
			}
			if (value) tBrowser.setAttribute("lockedBrowser", value);
			else tBrowser.removeAttribute("lockedBrowser");
		}
		return true;
	},

	/**
 	 * @brief Reverse the tab bar in all open windows.
	 *
	 * @param value	 		A Boolean. If true, then the function will
	 *				put the tabbar on the bottom of the window.
	 * 				If false, it will put it on the top.
	 * @returns			Nothing.
	 *
	 */
	reverseTabBar: function(value)
	{
		var _windows = this._windowManager.getEnumerator(BROWSER_WINDOWTYPE);
		var next;

		while (_windows.hasMoreElements()) {
			next = _windows.getNext().getBrowser();
			if (value) {
				// put the tab bar on the bottom using 'rtl'
				next.mTabBox.setAttribute("dir","rtl");
			}
			else {
				next.mTabBox.removeAttribute("dir");
			}
		}
		return;
	},

	/**
	 * @brief Show or hide the New Tab button in all windows.
	 *
	 * @param value	 		A Boolean. If true, then the function will
	 *				show the New Tab button. If false, it will hide it.
	 * @returns			Nothing.
	 *
	 */
	showTabButton: function(value)
	{
		var _windows = this._windowManager.getEnumerator(BROWSER_WINDOWTYPE);
		var newTabButton, tBrowser, i;

		while (_windows.hasMoreElements()) {
			tBrowser = _windows.getNext().getBrowser();
			newtabButton = tBrowser.mStrip.mNewTabButton;
			if (newtabButton) newtabButton.hidden = !value;
		}
		return;
	}
};

/**
 * @brief Lock a newly created tab.
 *
 * This function is internally called by any function responsible for
 * creating new tabs, and will only lock tabs whose owning tabbrowser
 * has been locked using the pref extension.tabprefs.lockAllTabs.
 *
 * @param gBrowser		A scripted tabbrowser object.
 * @param newTab		The newly created tab.
 * @returns			Nothing.
 *
 */
function __TBP_lockThisTab(tBrowser, newTab)
{
	if (!tBrowser.hasAttribute("lockedBrowser")) return;
	newTab.tabLocked = true;
	return;
}

/**
 * @brief Update the state of the tab strip popup menu.
 *
 * FIXME: the presence of this menu breaks the <tabbrowser>.updatePopupMenu()
 * funtion, so we redo its functionality here too.
 *
 * @param popupMenu		The DOM node representing the popup menu.
 * @param contextTab		The DOM node representing the element the popup menu
 *				was fired on.
 * @return			false.
 *
 */
function TBP_updatePopupMenu(popupMenu, contextTab)
{
	var menuItems, tBrowser = findParentNode(contextTab, "tabbrowser");
	if (!tBrowser) return false;

	// if we rightclicked the New Tab button, disable everything
	if (contextTab && contextTab.localName == "menuitem"
		       && contextTab.getAttribute("xbl:inherits").indexOf("onnewtab")) {
		menuItems = popupMenu.getElementsByTagName("menuitem");
		for (var i = 0; i < menuItems.length; i++) {
			menuItems[i].disabled = true;
		}
		return true;
	}

	var disabled = tBrowser.mPanelContainer.childNodes.length == 1;
        menuItems = popupMenu.getElementsByAttribute("tbattr", "tabbrowser-multiple");
        for (var i = 0; i < menuItems.length; i++)
		menuItems[i].disabled = disabled;

	menuItems = popupMenu.getElementsByAttribute("hidethis", "true");
	if (menuItems.length == 0) return false;
	
	// if there is no context tab, update the elements
	if (!contextTab || contextTab.localName != "tab") {
		menuItems[0].setAttribute("disabled", "true");
		menuItems[1].setAttribute("disabled", "true");
		menuItems[1].setAttribute("checked", false);
	}
	else {
		menuItems[0].removeAttribute("disabled");
		menuItems[1].removeAttribute("disabled");
		menuItems[1].setAttribute("checked", 'tabLocked' in contextTab ? contextTab.tabLocked : false);
	}
	return false;
}

/**
 * @brief Lock the context tab referenced by the tab strip popup.
 *
 * @param event			A valid event union.
 * @return			false.
 *
 */
function TBP_lockTab(event)
{
	var tBrowser = findParentNode(event.originalTarget, "tabbrowser");
	if (!tBrowser) return true;

	tBrowser.mContextTab.tabLocked = !tBrowser.mContextTab.tabLocked;
	return false;
}

/**
 * @brief Set up TBP's UI modifications.
 *
 * @param tBrowser		A valid DOM tabbrowser node.
 * @return	   		Nothing.
 *
 */
function TBP_initUI(tBrowser)
{
	// if we reenter this function, exit
	if (__UIsetup) return;

    	var strings = document.getElementById("tabprefsStrings");
	if (!strings) {
		throw "TBP_initUI: failure finding tabprefsStrings!";
	}

	if (!TBP_newTabButtonObserver._bundle) {
		TBP_newTabButtonObserver._bundle = document.getElementById("bundle_browser");
	}

	try {
		var newtabButton = tBrowser.mStrip.mNewTabButton;
		if (newtabButton) {
			newtabButton.hidden = !gPref.getBoolPref("extensions.tabprefs.showTabButton");
		}

		if (gPref.getBoolPref("extensions.tabprefs.reverseTab")) {
			tBrowser.mTabBox.setAttribute("dir","rtl");
		}
		TBP_prefObserver.lockAllTabs(gPref.getBoolPref("extensions.tabprefs.lockAllTabs"));
	}
	catch(e) {
		Components.utils.reportError(e);
	}

    	// create our menu elements and attach them
	var popupMenu = tBrowser.mStrip.mTabContextMenu;
    	var menusep = document.createElement('menuseparator');
       	menusep.setAttribute('hidethis', 'true');
	popupMenu.appendChild(menusep);

    	var menuitem = document.createElement('menuitem');
       	menuitem.setAttribute('label', strings.getString("LockTabMenu"));
       	menuitem.setAttribute('accesskey', strings.getString("LockTabKey"));
       	menuitem.setAttribute('type', 'checkbox');
       	menuitem.setAttribute('oncommand', 'TBP_lockTab(event);');
       	menuitem.setAttribute('hidethis', 'true');
	popupMenu.appendChild(menuitem);

	__UIsetup = true;
    	return;
}

/**
 * @brief Tear down TBP's UI modifications.
 *
 * @return			Nothing.
 *
 */
function TBP_exitUI(tBrowser)
{
	// unlock all tabs if needed
	TBP_lockAllTabs(false);
	return;
}

/*
 * provide an nsDragAndDrop observer for the new tab button provided on
 * the tab bar by TBP
 * shamelessly borrowed from Ben Basson, aka Cusser
 *
 */
var TBP_newTabButtonObserver = {
	_bundle: null,

	onDragStart: function(event, transferData, action)
	{
		var newTabContent, homePage, aPage;
		try {
			newTabContent = gPref.getIntPref("browser.tabs.loadOnNewTab");
			homePage = gPref.getCharPref("browser.startup.homepage");
		}
		catch(e) {
			homePage = "about:blank";
		}

		var aBrowser = findParentNode(event.originalTarget, "tabbrowser");
		if (!aBrowser || aBrowser.localName != "tabbrowser") {
			throw Components.results.NS_ERROR_FAILURE;
		}

		switch (newTabContent) {
			case 0 : {
				aPage = homePage.split("|")[0];
				break;
			}
			case 1 : {
				aPage = aBrowser.selectedBrowser.webNavigation.currentURI.spec;
				break;
			}
		}

		transferData.data = new TransferData();
		transferData.data.addDataForFlavour("text/unicode", aPage);
		transferData.data.addDataForFlavour("text/x-moz-url", aPage);
		transferData.data.addDataForFlavour("text/x-moz-tab", -1);
	},
	onDragOver: function(event, flavour, dragSession)
	{
		var statusTextFld = document.getElementById("statusbar-display");
		var statusTextNew;

		event.target.setAttribute("dragover", "true");
      		dragSession.dragAction = NS_CI.nsIDragService.DRAGDROP_ACTION_LINK;

		if (!this._bundle) return;
		statusTextNew = this._bundle.getString("droponnewtabbutton");
		statusTextFld.label = statusTextNew;
	},
	onDragExit: function (event, dragSession)
	{
		var statusTextFld = document.getElementById("statusbar-display");

		statusTextFld.label = "";
		event.target.removeAttribute("dragover");
	},
	onDrop: function (event, xferData, dragSession)
	{
		var loadNewInBackground;
		try {
			loadNewInBackground = gPref.getBoolPref("extensions.tabprefs.loadNewInBackground");
		}
		catch(e) {}
		var URI, charset, postData = null;

		var draggedData = transferUtils.retrieveURLFromData(xferData.data, xferData.flavour.contentType);
		if (!draggedData) return false;

		var aBrowser = findParentNode(event.originalTarget, "tabbrowser");
		if (!aBrowser) {
			throw Components.results.NS_ERROR_FAILURE;
		}

		URI = getShortcutOrURI(draggedData, postData);
		charset = aBrowser.selectedBrowser.contentDocument.characterSet;

        	aBrowser.dragDropSecurityCheck(event, dragSession, URI);
		try {
			aBrowser.loadOneTab(URI, null, charset, postData, loadNewInBackground);
		}
		catch(e) {
			Components.utils.reportError(e);
		}
		return true;
	},
	getSupportedFlavours: function ()
	{
		var flavourSet = new FlavourSet();
		flavourSet.appendFlavour("text/unicode");
		flavourSet.appendFlavour("text/x-moz-url");
		flavourSet.appendFlavour("application/x-moz-file", "nsIFile");
		return flavourSet;
	}
}
