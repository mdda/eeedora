/*
 * script/core.js
 *
 * this file contains all of the setup code
 *
 */

const BROWSER_WINDOWTYPE = "navigator:browser";

const NS_CC		 = Components.classes;
const NS_CI 		 = Components.interfaces;

var gPref2 		 = NS_CC["@mozilla.org/preferences-service;1"].
	    	       	   getService(NS_CI.nsIPrefBranch2);

var __TBP_coreInit = false;

/**
 * @brief Initialize browser-specific functions.
 *
 * @returns			Nothing.
 *
 */
function TBP_init()
{
	//var isPopup = TBP_checkForPopup(window.QueryInterface(NS_CI.nsIDOMWindow));

	BrowserStartup();

  	if (gBrowser) {
		gBrowser.removeEventListener("NewTab", BrowserOpenTab, false);
		gBrowser.addEventListener("NewTab", TBP_BrowserOpenTab, true);
		TBP_initUI(gBrowser);
  	}

	/*
	if (isPopup) {
		// replace the window's nsBrowserAccess with our own
		window.QueryInterface(NS_CI.nsIDOMChromeWindow).browserDOMWindow = new nsTBPBrowserAccess();
	}
	*/

	window.loadOneOrMoreURIs = TBP_LoadOneOrMoreURIs;

	// these things should only be added once
	if (__TBP_coreInit == false) {
		gPref2.addObserver("extensions.tabprefs.lockAllTabs", TBP_prefObserver, false);
		gPref2.addObserver("extensions.tabprefs.reverseTab", TBP_prefObserver, false);
		gPref2.addObserver("extensions.tabprefs.showTabButton", TBP_prefObserver, false);

		// this variable should be on the global JS scope for the inclusion within
		// a given XUL file overlaid by tabprefs.xul; therefore, it should act as a good
		// curb to avoid re-registering stuff over and over
		__TBP_coreInit = true;
	}
  	return true;
}

/**
 * @brief Shut down browser-specific functions.
 *
 * @returns			Nothing.
 *
 */
function TBP_exit()
{
	if (!gBrowser) {
		gBrowser = document.getElementById("content");
   		gBrowser.removeEventListener("NewTab", TBP_BrowserOpenTab, true);
		TBP_exitUI(gBrowser);
  	}

	// these things should only be removed once
	if (__TBP_coreInit == true) {
		gPref2.removeObserver("extensions.tabprefs.lockAllTabs", TBP_prefObserver);
		gPref2.removeObserver("extensions.tabprefs.reverseTab", TBP_prefObserver);
		gPref2.removeObserver("extensions.tabprefs.showTabButton", TBP_prefObserver);

		__TBP_coreInit = false;
	}

	BrowserShutdown();
  	return true;
}

/**
 * @brief Initialize the EM-specific functions.
 *
 * @returns			The return value of Startup().
 *
 */
function TBP_extInit()
{
	gExtensionsViewController.commands["cmd_homepage"] = TBP_openExtensionHomepage;
	return Startup();
}
