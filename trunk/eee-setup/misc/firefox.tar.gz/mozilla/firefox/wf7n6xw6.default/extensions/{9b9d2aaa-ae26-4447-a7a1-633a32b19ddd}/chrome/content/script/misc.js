/*
 * tpscript/misc.js
 *
 * contains all of the miscellaneous stuff
 *
 */

var gIOService =     NS_CC["@mozilla.org/network/io-service;1"].
		     getService(NS_CI.nsIIOService);
var gPref = 	     NS_CC["@mozilla.org/preferences-service;1"].
	    	     getService(NS_CI.nsIPrefBranch);
var gURIFixer =      NS_CC["@mozilla.org/docshell/urifixup;1"].
		     getService(NS_CI.nsIURIFixup);

/**
 * @brief Handle a left-click in a tab content area.
 *
 * This is attached singly to each tab, for the per-tab locking
 *
 * @param event			A valid event union.
 * @return			true if the event was not handled, or the
 *				return value of TBP_openURL.
 *
 */
function TBP_perTabContentClick(event)
{
	if (!event.isTrusted) return false;
    	if (event.button != 0) return true;
	if (is_ignorable(event.target) || is_ignorable(event.originalTarget)) {
		return true;
	}

	var linkNode, originCharset, ownerDocument;
	var target = event.target;
	var targetString = "_new_blank";
	var onclick = null, postData = { };

	if (target instanceof HTMLAnchorElement ||
	    target instanceof HTMLAreaElement ||
	    target instanceof HTMLLinkElement) {
		if (target.hasAttribute("href")) {
			linkNode = target;
		}
	}
	else {
		linkNode = event.originalTarget;
		while (linkNode && !(linkNode instanceof HTMLAnchorElement)) {
			linkNode = linkNode.parentNode;
		}
		// <a> cannot be nested.  So if we find an anchor without an
		// href, there is no useful <a> around the target
		if (linkNode && !linkNode.hasAttribute("href")) {
			return true;
		}
	}
	if (!(linkNode instanceof Node)) return false;

	ownerDocument = event.originalTarget.ownerDocument;
	originCharset = ownerDocument.characterSet;

	if (linkNode.hasAttribute("rel")) return true;
    	if (linkNode.getAttribute("target") &&
	    targetString.indexOf(linkNode.getAttribute("target").toLowerCase()) != -1) {
		// these are frame targets; they should be left alone
      		return true;
	}

	if (linkNode.hasAttribute("onclick")) onclick = linkNode.getAttribute("onclick");
	if (onclick != null && onclick.indexOf("window.open") == 0) {
		// gack - a JavaScript window.open call; this is _extremely_ tricky to
		// deal with, so it should be left alone, unfortunately
		return true;
	}

	var finalURI = fixupAURI(linkNode.href, ownerDocument.URL, originCharset);
	if (!finalURI) {
		return true;
	}

	return TBP_openURL(finalURI.spec, event, ownerDocument.URL,
			   originCharset, postData.value);
}

/**
 * @brief Handle text entry in the URL bar.
 *
 * @param event			A valid event union.
 * @returns			Nothing.
 *
 */
function TBP_handleURLBarCommand(event)
{
	// TBP_BrowserLoadURL() no longer calls getShortcutOrURI() directly,
	// as canonizeUrl() takes care of it for us
	var postData = { };
	canonizeUrl(event, postData);

	// ignore left-clicking
	if (event.type == "click" && event.button == 0) return;

	try {
		addToUrlbarHistory(gURLBar.value);
	}
	// Things may go wrong when adding url to session history,
	// but don't let that interfere with the loading of the url.
	catch (e) {}

	return TBP_BrowserLoadURL(event, postData.value);
}

/**
 * @brief Revert the URL bar to the URL of the currently selected browser.
 *
 * This was borrowed from chrome/browser.jar!/content/browser/browser.js:1840
 *
 * If "ESC" is pressed in the url bar, we replace the urlbar's value 
 * with the url of the page, unless it is about:blank, where we reset
 * it to "".
 *
 * @param browserTab		A DOM node represrnting a tabbrowser tab object.
 *				If non-NULL, the URL loaded into the tab object's
 *				browser is used to reset the URL bar. If NULL,
 *				the URL in the current tab's browser is used.
 * @returns			true if the URL bar dropdown is open,
 *				false if not.
 *
 */
function TBP_handleURLBarRevert(browserTab)
{
	var url;
	if (browserTab == null) {
		url = getWebNavigation().currentURI.spec;
	}
	else {
		// use the browserTab's currentURI instead
		url = gBrowser.getBrowserForTab(browserTab)
			      .webNavigation.currentURI.spec;
	}

	var throbberElement = document.getElementById("navigator-throbber");
	var isScrolling = gURLBar.popupOpen;

	// don't revert to last valid url unless page is NOT loading
	// and user is NOT key-scrolling through autocomplete list
	if ((!throbberElement ||
	     !throbberElement.hasAttribute("busy")) && !isScrolling) {
		if (url != "about:blank") {
			gURLBar.value = url;
			SetPageProxyState("valid");
		}
		else { //if about:blank, urlbar becomes ""
 			gURLBar.value = "";
			SetPageProxyState("invalid");
		}
	}

	gBrowser.userTypedValue = null;

	// tell widget to revert to last typed text only if the user
 	// was scrolling when they hit escape
	return !isScrolling;
}

/**
 * @brief Canonicalize a URI based upon a given URI.
 *
 * This function was kindly donated by Shelumi'El Jordan, S.D.G. aka MonkeeSage
 * and subsequently modified
 *
 * http://forums.mozillazine.org/viewtopic.php?t=86322
 *
 * @param relativeSpec		A string containing the relative URL.
 * @param currentSpec 		A string containing the base URL, used to
 *				make the relative URL absolute.
 * @param charset		The character set used to create the absolute URL.
 * @return			An |nsIURI| object containing the absolute URL,
 *				otherwise null.
 *
 */
function fixupAURI(relativeSpec, currentSpec, charset)
{
	var ignoredSchemes = '^(https?\:|ftp\:|news\:|mailto\:|smb\:' +
                               'gopher\:|about\:|file\:|cache\:' +
			       'javascript\:|x\-jsd\:|jar\:|resource\:|data\:)';
	var newURI, tempURI;

	if (relativeSpec.indexOf("urn:") == 0) {
		relativeSpec = xlate(relativeSpec);
	}

	// test the relative URL for the unwanted schemes
	var ignore = new RegExp(ignoredSchemes, 'i');
	if (ignore.test(relativeSpec)) {
		delete ignore;
		newURI = gIOService.newURI(relativeSpec, charset, null);
		return newURI;
	}

      	tempURI = gURIFixer.createFixupURI(currentSpec, 0); 
      	var host = tempURI.host, path = tempURI.path, proto = tempURI.scheme;   
      	if (relativeSpec[0] == '/') { 
        	path = '';
      	} 
      	else {
		// use a funky regexp to canonicalize the path token of the URI
        	path = path.replace(/(.+?\/?)[^\/]+?$/, "$1");
        	while (/\.\.\//i.test(relativeSpec)) {
            		relativeSpec = relativeSpec.replace(/\.\.\//i, '');
            		path = path.replace(/(.+?\/?)[^\/]+?\/$|([^\/]+?\/?)$/, "$1"); 
         	}
         	if (path[0] != '/') {
            		path = '/' + path; 
         	}
      	}

	// create the new URI out of the various parsed pieces
	newURI = gIOService.newURI(proto + '://' + host + path + relativeSpec, charset, null);
	delete ignore;
	return newURI;
}

/*
 * The following functions are borrowed from nodomws.js, the DOM Whitespace functions
 * found on the Mozilla Development site
 *
 * http://www.mozilla.org/docs/dom/technote/whitespace/
 *
 */

/**
 * Determine whether a node's text content is entirely whitespace.
 *
 * @param nod  A node implementing the |CharacterData| interface (i.e.,
 *             a |Text|, |Comment|, or |CDATASection| node
 * @return     True if all of the text content of |nod| is whitespace,
 *             otherwise false.
 */
function is_all_ws(nod)
{
	// Use ECMA-262 Edition 3 String and RegExp features
	return !(/[^\t\n\r ]/.test(nod.data));
}


/**
 * Determine if a node should be ignored by the iterator functions.
 *
 * @param nod  An object implementing the DOM1 |Node| interface.
 * @return     true if the node is:
 *                1) A |Text| node that is all whitespace
 *                2) A |Comment| node
 *             and otherwise false.
 */

function is_ignorable(nod)
{
	return  (nod.nodeType == 8) || // A comment node
		((nod.nodeType == 3) && is_all_ws(nod)); // a text node, all ws
}

/**
 * @brief Find the parent node of a DOM node.
 *
 * This was borrowed from chrome://global/help/content/help.js:538
 *
 * @param node			A node within a DOM tree that is a |Node|.
 * @param parentNode		A string containing the localName of a |Node|
 * 				within the DOM tree that is the parent of
 *				the node in the first argument.
 * @returns			The |Node| whose localName matches the second
 *				argument, or null.
 *
 */
function findParentNode(node, parentNode)
{
	if (node && node.nodeType == Node.TEXT_NODE) {
		node = node.parentNode;
	}
	while (node) {
		if (node.nodeType == Node.DOCUMENT_NODE) {
			return null;
		}

		var nodeName = node.localName;
		if (!nodeName)
			return null;

		nodeName = nodeName.toLowerCase();
	    	if (nodeName == "body" || nodeName == "html") {
			return null;
		}
		if (nodeName == parentNode)
			return node;

		node = node.parentNode;
	}
	return null;
}

/**
 * @brief Load the throbber URL in a new tab.
 *
 * This redefines chrome://browser/content/utilityOverlay.js:goClickThrobber()
 *
 * @param event			A valid event union.
 * @return			The return value of TBP_openURL().
 *
 */
function TBP_goClickThrobber(event)
{
	var URL;
	var LocalizedString = NS_CI.nsIPrefLocalizedString;
	try {
		URL = gPref.getComplexValue("browser.throbber.url", LocalizedString).data;
	}
 	catch(e) {
	    	URL = null;
  	}

	return TBP_openURL(URL, event, null, null, null);
}

/**
 * @brief Focus the URL bar, if it exists.
 *
 * @return			Nothing.
 *
 */
function TBP_focusURLBar()
{
	if (gURLBar) gURLBar.focus();
	return;
}

/**
 * @brief Open the homepage of an extension.
 *
 * @param selectedItem		A DOM node representing the selected extension.
 * @return			Nothing.
 *
 */
function TBP_openExtensionHomepage(selectedItem)
{
	if (!selectedItem) return;
	var homepageURL = selectedItem.getAttribute("homepageURL");

	// only allow http(s) homepages
	var scheme = "";
	var uri = null;
	try {
		uri = makeURI(homepageURL);
		scheme = uri.scheme;
	}
	catch (e) {}

	if (uri && (scheme == "http" || scheme == "https")) {
		TBP_openURL(uri.spec, null, null, null, null);
	}
	return;
}
 
/**
 * @brief Checks an event union for various modifier keys.
 *
 */
var TBP_eventChecker = {
	isValid: function(aEvent)
	{
		return aEvent && aEvent instanceof Event;
	},
	altKeypress: function(aEvent)
	{
		if (!this.isValid(aEvent)) return false;
		return 'altKey' in aEvent && aEvent.altKey;
	},
	ctrlKeypress: function(aEvent)
	{
		if (!this.isValid(aEvent)) return false;
		return 'ctrlKey' in aEvent && aEvent.ctrlKey;
	}
};
