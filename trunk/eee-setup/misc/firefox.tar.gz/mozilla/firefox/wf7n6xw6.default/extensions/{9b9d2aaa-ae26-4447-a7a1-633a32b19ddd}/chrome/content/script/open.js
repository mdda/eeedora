/*
 * tpscript/open.js
 *
 * this file contains the all routines directly responsible
 * for opening tabs or URLs
 *
 */

var gIOService =     NS_CC["@mozilla.org/network/io-service;1"].
		     getService(NS_CI.nsIIOService);
var gPref = 	     NS_CC["@mozilla.org/preferences-service;1"].
	    	     getService(NS_CI.nsIPrefBranch);
var gWindowManager = NS_CC["@mozilla.org/appshell/window-mediator;1"].
		     getService(NS_CI.nsIWindowMediator);

/** * @brief Open a new tab.
 *
 * This function is called in the following contexts:
 * - the cmd_newNavigatorTab command, in browser.xul's mainCommandSet
 * - the tabbrowser, via the onnewtab attribute (equiv. to oncommand)
 * - the New Tab button in the tabbrowser-strip-newtab binding
 * - the "NewTab" event sent by the tabbrowser onTabBarDblClick()
 *   event handler
 *
 * This function uses findParentNode() to locate the tabbrowser that we are
 * listening on; this way we can guarantee that we open the tab in the right
 * place, and are not dependent on the scope of gBrowser. If event is NULL
 * (which it might be), we'll just use gBrowser anyway.
 *
 * @param event			A valid event union. This can be NULL.
 * @return			false.
 *
 */
function TBP_BrowserOpenTab(event)
{
	var newTabContent, loadNewInBackground, focusURLBar;
	var newTab = null, URI;
	var originCharset;

   	try {
		newTabContent =	       gPref.getIntPref("browser.tabs.loadOnNewTab");
		loadNewInBackground =  gPref.getBoolPref("extensions.tabprefs.loadNewInBackground");
                focusURLBar =          gPref.getBoolPref("extensions.tabprefs.focusURLBarOnNewTab");
   	}
   	catch(e) {
		newTabContent = 2;
		loadNewInBackground = false;
		focusURLBar = true;
	}

	// if event is null, use gBrowser anyway
	var tBrowser = findParentNode(event.target, "tabbrowser");
	if (!tBrowser) tBrowser = gBrowser;
	originCharset = tBrowser.selectedBrowser.contentDocument.characterSet;

	switch (newTabContent) {
		case 0 : { // home page
     			// we split on a pipe character to get the first URL of a potential grouped
     			// homepage - we don't want to load multiple tabs
			URI = gHomeButton.getHomePage().split("|")[0];
			break;
		}
		case 1 : { // current URI
			URI = tBrowser.selectedBrowser.webNavigation.currentURI.spec;
			break;
		}
 		case 2 : { // blank tab, by default
    			URI = "about:blank";
			break;
		}
	}
	newTab = tBrowser.loadOneTab(URI, null, originCharset, null, loadNewInBackground);
	__TBP_lockThisTab(tBrowser, newTab);

       	if (focusURLBar) setTimeout(TBP_focusURLBar, 0);

  	event.preventDefault();
    	event.stopPropagation();

	// this is done for the benefit of Twanno's TCO extension;
	// returning the tab object allows his extension to work better
    	return newTab;
}

/**
 * @brief Load the home page.
 *
 * @returns			Nothing.
 *
 */
function TBP_BrowserHome()
{
	if (!gHomeButton) return;
	var homePage = gHomeButton.getHomePage();

	var buttonPref, replacePref, deletePref;
	try {
		buttonPref =  gPref.getIntPref("extensions.tabprefs.homePageButtonTarget");
		deletePref =  gPref.getBoolPref("extensions.tabprefs.closeExtraTabsOnReplace");
		replacePref = gPref.getBoolPref("browser.tabs.loadFolderAndReplace");
	}
	catch(e) {
		// always load in the current tab
		buttonPref = 0;
		replacePref = false;
		deletePref = true;
	};

	__TBP_LoadOneOrMoreURIs(homePage, buttonPref, replacePref, deletePref);
	return;
}

/**
 * @brief Load the home page when clicking the Home button.
 *
 * @param event			A valid event union.
 * @return			true if the homepage(s) were loaded
 *				successfully, false if the homepage(s)
 *				could not be accessed.
 *
 */
function TBP_BrowserHomeClick(event)
{
	// right-click: do nothing
	if (event.button == 2) return false;
	if (!gHomeButton) return false;

  	var homePage = gHomeButton.getHomePage();
  	var where = whereToOpenLink(event);

	var buttonPref, replacePref, deletePref;
	try {
		buttonPref =  gPref.getIntPref("extensions.tabprefs.homePageButtonTarget");
		deletePref =  gPref.getBoolPref("extensions.tabprefs.closeExtraTabsOnReplace");
		replacePref = gPref.getBoolPref("browser.tabs.loadFolderAndReplace");
	}
	catch(e) {
		// always load in the current tab
		buttonPref = 0;
		replacePref = false;
		deletePref = true;
	};

 	// FIX: override the prefs when middle-clicking
	if (event.button == 1) buttonPref = 1;

	switch (where) {
		case "window": {
			// this implicitly opens the homepage
			OpenBrowserWindow();
			break;
		}
		case "save": {
			// save the first page only
			var urls = homePage.split("|");
			saveURL(urls[0], null, null, true, null, null);
			break;
		}
		default : {
			__TBP_LoadOneOrMoreURIs(homePage, buttonPref, replacePref, deletePref);
			break;
		}
	}

	event.preventDefault();
	event.stopPropagation();
	return true;
}
		
/**
 * @brief Load one or more URLs.
 *
 * This function is meant to be used by 'normal' browser code. Note that this
 * function is called by BrowserStartup(), which is rather unfortunate.
 *
 * @param aURIString		A string of pipe-delimited URI(s).
 * @return			Nothing.
 *
 */
function TBP_LoadOneOrMoreURIs(aURIString)
{
	var buttonPref, replacePref, deletePref;
	try {
		buttonPref =  gPref.getIntPref("extensions.tabprefs.homePageButtonTarget");
		deletePref =  gPref.getBoolPref("extensions.tabprefs.closeExtraTabsOnReplace");
		replacePref = gPref.getBoolPref("browser.tabs.loadFolderAndReplace");
	}
	catch(e) {}

	__TBP_LoadOneOrMoreURIs(aURIString, buttonPref, replacePref, deletePref);
	return;
}

/**
 * @brief Load one or more URLs.
 *
 * This function is used directly by TBP, and is used to load multiple URLs
 * when the Home button is clicked or the homepages are otherwise loaded.
 *
 * @param aURIString		A string of pipe-delimited URI(s).
 * @param aButtonPref		An integer value that sets the focus of the first URL in
 *				a list of pipe-delimited URLs. If true, the first URL in
 *				the list (|urls[0]|) will be focused; if false, it will not.
 * @param aReplacePref		A Boolean value which is used to determine whether or
 *				not the URLs in any existing opened tabs will be replaced
 *				with URLs parsed from |aURIString|.
 * @param aDeletePref		A Boolean value which is used to determine whether or
 *				not any tabs left over after |aURIString| has been fully
 *				opened will be deleted.
 * @return			Nothing.
 *
 */
function __TBP_LoadOneOrMoreURIs(aURIString, aButtonPref, aReplacePref, aDeletePref)
{
	if (!aURIString) return;
	var postData = null;
	var i, j, tabs, cTab, b;

	// if aButtonPref is not zero, load the first URL in a new tab
	var aTabPref = (aButtonPref != 0);
	// if aButtonPref is one, focus the first URL's tab
	var aFGPref = (aButtonPref == 1);

	var urls = aURIString.split("|");

	var originCharset = gBrowser.selectedBrowser.characterSet;
	var urlSpec = gBrowser.selectedBrowser.webNavigation.currentURI.spec;

	var isBusy = gBrowser.mCurrentTab.hasAttribute("busy");
	var isLocked = gBrowser.mCurrentTab.tabLocked;
	var tabPos = gBrowser.mCurrentTab._tPos;

	// if the current URL is about:blank and the tab is not busy
	// and the tab is not locked, load the first URL in the current tab
	if (urlSpec == "about:blank" && !isBusy && !isLocked) {
		gBrowser.loadURI(urls[0], null, null);
	}
	// else, if tab replacement is enabled and the tab is not
	// locked, load the first URL in the current tab
	else if (aReplacePref && !isLocked) {
		gBrowser.loadURI(urls[0], null, null);
	}
	else if (aTabPref || isLocked) {
		var newTab = gBrowser.loadOneTab(urls[0], null, originCharset, postData, !aFGPref);
		gBrowser.moveTabTo(newTab, ++tabPos);
		__TBP_lockThisTab(gBrowser, newTab);
	}
	else {
		gBrowser.loadURI(urls[0], null, originCharset);
	}
	// if we are replacing tabs, iterate over each opened browser and load the
	// URI at that index into it
	if (aReplacePref) {
		b = gBrowser.browsers;

		// determine how many open tabs we have
		if (b.length >= urls.length) {
			// tabs outnumber browsers, open as many URLs as possible
			// and then delete the remaining tabs
			for (i = 1; i < urls.length; ++i) {
				b[i].loadURI(urls[i], null, originCharset);
			}
			tabs = gBrowser.mTabs;
			if (aDeletePref) {
				for (j = i; j < b.length; ++j) {
					gBrowser.removeTab(tabs[i]);
				}
			}
		}
		else if (urls.length > b.length) {
			// URLs outnumber tabs, open as many URLs as possible
			// and then add new contiguous tabs for the remaining URLs
			for (i = 1; i < b.length; ++i) {
				b[i].loadURI(urls[i], null, originCharset);
			}
			for (j = i; j < urls.length; ++j) {
				cTab = gBrowser.addTab(urls[i], null, originCharset, postData, newTab);
				gBrowser.moveTabTo(cTab, ++tabPos);
				__TBP_lockThisTab(gBrowser, cTab);
			}
		}
	}
	else {
		// simply load each URL into the currently selected tabbrowser, making
		// them contiguous with one another
		for (i = 1; i < urls.length; ++i) {
			cTab = gBrowser.addTab(urls[i], null, originCharset, postData, newTab);
			gBrowser.moveTabTo(cTab, ++tabPos);
			__TBP_lockThisTab(gBrowser, cTab);
		}
	}

	// last but not least, focus the page content
	content.focus();
	return;
}

/**
 * @brief Load URLs from the URL bar.
 *
 * @param event			A valid event union.
 * @param aPostData		Data to be attached to HTTP POST requests. Generally NULL.
 * @return			Nothing.
 *
 */
function TBP_BrowserLoadURL(event, aPostData)
{
	var theTabPref, theFGPref;

	var theURI = gURLBar.value;
	var ctrlKey = TBP_eventChecker.ctrlKeypress(event);
	var altKey = TBP_eventChecker.altKeypress(event);
	var originCharset = gBrowser.selectedBrowser.characterSet;

	try {
       		theTabPref =  gPref.getBoolPref("browser.tabs.opentabfor.urlbar");
       		theFGPref =   gPref.getBoolPref("extensions.tabprefs.urlbarSelect");
	}
	catch(e) {}

	// if the current tab is busy, don't use it
	if (gBrowser.mCurrentTab.hasAttribute("busy")) {
		theTabPref = true;
	}

	// if the current tab is empty, use it
	if (gBrowser.selectedBrowser.webNavigation.currentURI.spec == "about:blank") {
		theTabPref = false;
		theFGPref = false;
	}

	// if the Go button was middle-clicked, open a new tab
	if (event.type == "click" && event.button == 1) {
		theTabPref = true;
		try {
			theFGPref = gPref.getBoolPref("extensions.tabprefs.urlbarSelect");
		}
		catch(e) {}
	}

	// if the Alt key was used but theTabPref is false, open in a new focused tab
        if (altKey && !theTabPref) {
		theTabPref = true;
		theFGPref = true;
	}

	// also open a new tab if the current tab is locked
	if (theTabPref || gBrowser.selectedTab.tabLocked) {
		TBP_handleURLBarRevert(gBrowser.selectedTab);
       		newTab = gBrowser.loadOneTab(theURI, null, originCharset, aPostData, !theFGPref);
		__TBP_lockThisTab(gBrowser, newTab);
	}
     	else {
        	loadURI(theURI, null, originCharset);
     	}
     	content.focus();

     	if (TBP_eventChecker.isValid(event)) {
     		event.preventDefault();
     		event.stopPropagation();
	}
	return;
}

/**
 * @brief Handle left-clicks on links within a help browser
 *
 * NOTE: Shift, Ctrl, and Meta are all ignored
 *
 * @param event			A valid event union.
 * @return			true if the event was not handled;
 *				false if it was handled and a URI was
 *				loaded, or the return value of TBP_openURL().
 *
 */
function TBP_helpContentClick(event)
{
	var helpBrowser = document.getElementById("help-content");
	if (!helpBrowser) {
		return true;
	}

    	if (event.button != 0) return true;
	if (is_ignorable(event.target) || is_ignorable(event.originalTarget)) {
		return true;
	}

	var linkNode;
	var target = event.target;

	if (target instanceof HTMLAnchorElement ||
	    target instanceof HTMLAreaElement ||
	    target instanceof HTMLLinkElement) {
		if (target.hasAttribute("href")) {
			linkNode = target;
		}
	}
	else {
		linkNode = event.originalTarget;
		while (linkNode && !(linkNode instanceof HTMLAnchorElement)) {
			linkNode = linkNode.parentNode;
		}
		// <a> cannot be nested.  So if we find an anchor without an
		// href, there is no useful <a> around the target
		if (linkNode && !linkNode.hasAttribute("href")) {
			return true;
		}
	}
	var uriSpec;
	if (linkNode instanceof Node && linkNode.hasAttribute("href")) {
		uriSpec = linkNode.href;
	}
	if (!uriSpec || uriSpec == undefined) {
		return true;
	}

	// do not handle URIs that are not http, ftp or https
	if (!(uriSpec.indexOf("http") == 0) && !(uriSpec.indexOf("https") == 0) &&
	    !(uriSpec.indexOf("ftp") == 0)) {
        	helpBrowser.loadURI(uriSpec);
        	return false;
   	}

    	return TBP_openURL(uriSpec, event, null, null, null);
}

/**
 * @brief Load URLs into new tabs or new windows.
 *
 * This redefines chrome://mozapps/content/extensions/extensions.js:openURL()
 * into a more general purpose function that can be reused by other extensions.
 * This function does not check to see if the primary URL scheme is sensible,
 * but will check if the referrer URL scheme is sensible. The URL string passed
 * to this function may be pipe-delimited; the string will be parsed and the
 * first URL will be loaded according to the tab prefs, with the remainder being
 * loaded into the background. Any tabs created by this function will be locked
 * if the browser element selected by the function is also locked.
 *
 * This function reads the following preferences:
 *   browser.link.open_newwindow
 *   browser.tabs.loadInBackground
 *
 * @param aURL			A valid URI string.
 * @param event			A valid event union. This can be null when
 *				calling this function.
 * @param aRefURL		The URL of the document that aURL came from. The
 *				scheme of the URL may not be about:.
 * @param charset      		The document character set that the URL should use.
 *				If NULL the character set of the currently displayed
 *				browser in the most recent browser window will be used.
 * @param postData		Data to be attached to HTTP POST requests. This is
 *				generally likely to be NULL.
 *
 * @return			true.
 *
 */
function TBP_openURL(aURL, event, aRefURL, charset, postData)
{
	var linkTarget, loadInBackground, where, referrer;
   	try {
      		linkTarget = 	   gPref.getIntPref("browser.link.open_newwindow");
		loadInBackground = gPref.getBoolPref("browser.tabs.loadInBackground");
   	}
   	catch (e) {
		linkTarget = 1;
	}

	var anyBrowser = gWindowManager.getMostRecentWindow(BROWSER_WINDOWTYPE).getBrowser();
	var originCharset = charset ? charset : anyBrowser.selectedBrowser.contentDocument.characterSet;

	if (aURL == null) aURL = "about:blank";
	var urls = aURL.split("|");
	
	// if the referrer is null, or has an about: scheme, don't use it
	if (aRefURL == null || aRefURL.indexOf("about:") == 0) {
		referrer = null;
	}
	else {
		// the referrer arg to nsIWebNavigation.loadURIWithFlags()
		// is an nsIURI, NOT a jschar string
		referrer = gIOService.newURI(aRefURL, originCharset, null);
	}

	if (TBP_eventChecker.isValid(event)) {
		where = whereToOpenLink(event);
		if (where == "save") {
			saveURL(urls[0], null, null, true, null, refURL);
			return true;
		}
		else if (where == "window") {
			linkTarget = 2;
		}
	}

	if (anyBrowser.selectedBrowser.webNavigation.currentURI.spec == "about:blank") {
		linkTarget = 1;
	}
	else if (anyBrowser.selectedTab.tabLocked) {
		linkTarget = 3;
	}

	var i = 0;
     	switch (linkTarget) {
		case 1 : {
        	 	anyBrowser.loadURI(urls[i], referrer, originCharset);
			for (i = 1; i < urls.length; ++i) {
        	 		cTab = anyBrowser.loadOneTab(urls[i], referrer, originCharset,
							     postData, true);
				__TBP_lockThisTab(anyBrowser, cTab);
			}
        		break;
       		}
       		case 2 : {
         		openNewWindowWith(urls[i], referrer.spec, postData);
          		break;
       		}
       		case 3 : {
			var newTab = anyBrowser.loadOneTab(urls[i], referrer, originCharset,
							   postData, loadInBackground);
			__TBP_lockThisTab(anyBrowser, newTab);

			for (i = 1; i < urls.length; ++i) {
        	 		cTab = anyBrowser.loadOneTab(urls[i], referrer,
							     originCharset,
							     postData, true);
				__TBP_lockThisTab(anyBrowser, cTab);
			}
        	 	break;
       		}
     	}

	if (TBP_eventChecker.isValid(event)) {
		event.preventDefault();
		event.stopPropagation();
	}
   	return true;
}
