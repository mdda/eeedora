/*
 * tpscript/popup.js
 *
 * this code handles links inside popup windows
 *
 */

/*
 * nsTBPBrowserAccess, a replacement for nsBrowserAccess
 *
 * This version of nsBrowserAccess is designed to be installed on windows
 * that are popup windows. It replaces the openURI() function with a
 * customized version that seeks only to load URIs into the window (which
 * is co-terminous with the currently selected tab of the tabbrowser inside
 * the window) if the URI being loaded has a hostname equal to the URI
 * already present. Otherwise, all other loads are sent to the browser that
 * opened the window that nsTBPBrowserAccess.openURI() was called on.
 *
 */
function nsTBPBrowserAccess()
{
	this._ioService = NS_CC["@mozilla.org/network/io-service;1"]
			   .getService(NS_CI.nsIIOService);
	this._prefs = NS_CC["@mozilla.org/preferences-service;1"]
			   .getService(NS_CI.nsIPrefBranch);
	this._windowManager = NS_CC["@mozilla.org/appshell/window-mediator;1"]
			   .getService(NS_CI.nsIWindowMediator);
}
nsTBPBrowserAccess.prototype =
{
	_ioService: null,
	_prefs: null,
	_windowManager: null,

	QueryInterface : function(aIID)
	{
		if (aIID.equals(NS_CI.nsIBrowserDOMWindow) ||
 		    aIID.equals(NS_CI.nsISupports))
			return this;

		throw Components.results.NS_NOINTERFACE;
	},

	/**
	 * @brief Open a URI from a popup window in a browser window.
	 *
	 * @param aURI			A valid URI string.
	 * @param aOpener		A DOM window object, representing the window
	 *				 that |aURI| originated from. This can be null.
	 * @param aWhere		One of the constants from |nsIBrowserDOMWindow|
	 *				 indicating how the caller expects the URL to
	 * 				 be handled.
	 * @param aContext		One of the constants from |nsIBrowserDOMWindow|
	 *				 defining the load source of the URL, i.e.
	 *				 whether or not the URL came from inside or
	 *				 outside the program.
	 * @throws			"unable to find non-popup window" when the function
	 *				 cannot find a suitable full-feature browser window
	 *				 to send the URL to, or "no browsers available" when
	 *				 the function is unable to find a suitable tabbrowser
	 *				 to load the URL in. Other exceptions may be thrown.
	 * @return			The |nsIDOMWindow| representation of the window
	 *				 where the URL was finally handled, or NULL if an
	 *				 error occurred or an exception was thrown.
	 *
	 */
	openURI : function(aURI, aOpener, aWhere, aContext)
	{
		var newWindow = null;
		var loadflags, browserToUse, isExternal, divertPopupLinks;
		var url, currentURI, newURI;

		var DOMWindow = NS_CI.nsIBrowserDOMWindow;

		try {
			divertPopupLinks = this._prefs.getIntPref("extensions.tabprefs.divertPopupLinks");
		}
		catch(e) {
			divertPopupLinks = 0;
		}

		/*
		 * This function is always called on windows that were checked
		 * and passed as popups when TBP_init() was called on the window.
		 * Therefore, the following conditions are assumed:
		 *
		 * isExternal loads are _always_ kicked to a full-size browser.
		 * OPEN_DEFAULTWINDOW loads are _always_ kicked to a full-size browser.
		 * all loads sent to the full-size browser are opened in a new tab,
		 *  focused according to the preferences.
		 * 
		 * All other URIs passed into this function are parsed and their
		 * domains checked against the current URI of the current browser tab.
		 * If they match, the link is opened in the popup window. If not,
		 * it is opened in the current browser - the most recent browser window,
		 * or any browser window that is not a popup window too.
		 *
	 	 * The value of the preference extensions.tabprefs.divertPopupLinks
		 * is used to determine how to load the URLs into a full window. If
		 * the value is zero, a dissimilar URL is loaded into the browser
		 * window's current tab. If it is 1, it is loaded into a new focused
		 * tab. If it is 2, it is loaded into a new unfocused tab.
		 *
		 */

		// find a non-popup browser window
		var recentWindow = this._windowManager.getMostRecentWindow(BROWSER_WINDOWTYPE);
		if (TBP_checkForPopup(recentWindow.QueryInterface(NS_CI.nsIDOMWindow))) {
			// iterate the list of open windows backwards to find the
			// youngest non-popup window we can use
			var windows = this._windowManager.getZOrderDOMWindowEnumerator(BROWSER_WINDOWTYPE, true);
			recentWindow = null;
			while (windows.hasMoreElements()) {
				recentWindow = windows.getNext();
				if (TBP_checkForPopup(recentWindow.QueryInterface(NS_CI.nsIDOMWindow))) {
					alert("popup window");
					recentWindow = null;
					continue;
				}
			}
			if (recentWindow == null) {
				throw "nsTBPBrowserAccess: unable to find non-popup window";
				return null;
			}
		}

		// these acrobatics are needed because aOpener is sometimes not defined
		var openerBrowser = aOpener.getBrowser ? aOpener.getBrowser() : window.getBrowser();
		var parentBrowser = recentWindow.getBrowser();

		if (!(openerBrowser instanceof Node) || !(parentBrowser instanceof Node)) {
			throw Components.results.NS_ERROR_UNEXPECTED;
			return null;
		}
		else if ((openerBrowser.localName != "tabbrowser") || (parentBrowser.localName != "tabbrowser")) {
			throw "nsTBPBrowserAccess: no browsers available";
			return null;
		}
		currentURI = this._ioService.newURI(openerBrowser.selectedBrowser.webNavigation.currentURI.spec, null, null);

		url = aURI ? aURI.spec : "about:blank";
		newURI = this._ioService.newURI(url, null, null);

		isExternal = (aContext == DOMWindow.OPEN_EXTERNAL);
		if (isExternal && aURI && aURI.schemeIs("chrome")) {
			dump("use -chrome command-line option to load external chrome urls\n");
			return null;
		}
		else if (isExternal) {
			// kick the load upstairs
			browserToUse = parentBrowser;
			loadflags = NS_CI.nsIWebNavigation.LOAD_FLAGS_FROM_EXTERNAL;
		}
		else {
			browserToUse = openerBrowser;
			loadflags = NS_CI.nsIWebNavigation.LOAD_FLAGS_NONE;
		}

		if (aWhere == DOMWindow.OPEN_DEFAULTWINDOW) {
			browserToUse = parentBrowser;
		}

		// check for equal hostnames in the URIs
		try {	
			if (currentURI.host == newURI.host) {
				browserToUse = openerBrowser;
				// force the URI into the current tab in the
				// popup window
				divertPopupLinks = 0;
			}
			else {
				browserToUse = parentBrowser;
			}
		}
		catch(e) {
			Components.utils.reportError(e);
			browserToUse = openerBrowser;
		}

		if (!browserToUse) {
			throw "nsTBPBrowserAccess: no browsers available";
			return null;
		}

		/*
 		 * aWhere is no longer really needed, as all three types of loads in a popup
		 * window no longer need separate handling - they all get punted to the
		 * parent window's browser if they failed the same-hostname check
		 *
		 */
		switch (divertPopupLinks) {
			case 0 : {	// OPEN_CURRENTWINDOW
				newWindow = browserToUse.selectedBrowser.docShell
						.QueryInterface(NS_CI.nsIInterfaceRequestor)
                            			.getInterface(NS_CI.nsIDOMWindow);
				try {
  					newWindow.QueryInterface(NS_CI.nsIInterfaceRequestor)
						.getInterface(nsIWebNavigation)
						.loadURI(newURI.spec, loadflags, currentURI.spec, null, null);

					// focus on the newly loaded URL
					browserToUse.selectedBrowser.contentDocument.focus();
				}
				catch(e) {
					Components.utils.reportError(e);
				}
				break;
			}
			case 1 :
			case 2 : {	// OPEN_NEWTAB
				var value = divertPopupLinks == 2 ? true : false;
				var newTab = browserToUse.loadOneTab("about:blank", null, null, null, value);
        			newWindow = browserToUse.getBrowserForTab(newTab).docShell
                            			.QueryInterface(NS_CI.nsIInterfaceRequestor)
                            			.getInterface(NS_CI.nsIDOMWindow);
				try {
					newWindow.QueryInterface(NS_CI.nsIInterfaceRequestor).getInterface(NS_CI.nsIWebNavigation)
						.loadURI(newURI.spec, loadflags, currentURI.spec, null, null);
				}
				catch(e) {
					Components.utils.reportError(e);
				}
				break;
			}
		}
		return newWindow;
	},

	isTabContentWindow : function(aWindow)
	{
		var browsers = gBrowser.browsers;
		for (var ctr = 0; ctr < browsers.length; ctr++) {
			if (browsers.item(ctr).contentWindow == aWindow) {
				return true;
			}
		}
		return false;
	}
}

/**
 * @brief Checks to see if a given nsIDOMWindowInternal object is a popup or not.
 *
 * @param domWindow	   An |nsIDOMWindowInternal| representation of a window.
 * @return		   true if the domWindow is a popup, false otherwise.
 *
 */
function TBP_checkForPopup(domWindow)
{
	if (!(domWindow instanceof NS_CI.nsIDOMWindowInternal)) return false;

	// FIXME: locationbar, menubar, toolbar -
	// if these are hidden the window is probably a popup
	var locbar =  domWindow.locationbar.QueryInterface(NS_CI.nsIDOMBarProp);
	var menubar = domWindow.menubar.QueryInterface(NS_CI.nsIDOMBarProp);
	var toolbar = domWindow.toolbar.QueryInterface(NS_CI.nsIDOMBarProp);

	// the following logic, while possibly slow, is designed
	// to catch all reasonable permutations of hidden UI
	if ((!locbar.visible && !menubar.visible && !toolbar.visible) ||
            (!locbar.visible && !menubar.visible) ||
            (!menubar.visible && !toolbar.visible)) {
		return true;
	}
	return false;
}
