/**
  Distrust - Cleans up browser trails and leftovers
  Copyright (C) 2006 Itamar Kerbel
  http://www.gness.org/
  trustme@gness.com

  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation; either version 2.1 of the License, or (at
  your option) any later version.

  This library is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESSFOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
  for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with this library; if not, write to the Free Software Foundation,
  Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
**/

//cookie prefs were based upon  http://lxr.mozilla.org/mozilla/source/xpfe/components/prefwindow/resources/content/pref-cookies.xul#77
const accept_normally = "0";
const accept_session = "2";
const accept_for_n_days = "3";
const ask_before_accepting = "1";

const FORM_FILL_PREF = "browser.formfill.enable";
const COOKIE_LIFETIME_PREF = "network.cookie.lifetimePolicy";
const DISK_CACHE_PREF = "browser.cache.disk.enable";
const DISK_CACHE_SSL_PREF = "browser.cache.disk_cache_ssl";
const MAX_UNDO_TABS_PREF = "browser.sessionstore.max_tabs_undo";
const FF_VERSION = "extensions.lastAppVersion";
const NC_NS = "http://home.netscape.com/NC-rdf#";

const DT_CRASH_RECOVER_FLAG = "distrust.core.crashFlag";
const DT_CRASH_RECOVER_DATA_BRANCH = "distrust.core.crash.";
const DT_CRASH_RECOVER_COOKIE_VAL = "distrust.core.crash.origCookieBehavior";
const DT_CRASH_RECOVER_DISK_CACHE_VAL = "distrust.core.crash.origDiskCache";
const DT_CRASH_RECOVER_DISK_CACHE_SSL_VAL = "distrust.core.crash.origDiskCacheSSL";
const DT_CRASH_RECOVER_FORM_FILL_VAL = "distrust.core.crash.origFormFill";
const DT_CRASH_RECOVER_MAX_UNDO_TABS_VAL = "distrust.core.crash.origMaxUndoTabs";


var privacyState = false;
var origLifetimeBehavior = -3; //not a valid value
var origDiskCache = true; //usualy used
var origDiskCacheSSL = false; //usualy used
var origFormFill = true;//usualy used
var origMaxUndoTabs = 10;//This is hard coded in FF (http://lxr.mozilla.org/seamonkey/source/browser/app/profile/firefox.js#548)
var initTime = null;
var downloadsToRemove = new Array();
var downloadIDsToRemove = new Array();

var cookiePref = true;
var diskCachePref = true;
var formInfoPref = true;
var historyPref = true;
var downloadsPref = true;
var undoTabsPref = true;
var sloPref = true;
var firstWindowRegistering = true;


function logMsg(aMessage)
{
	if (false) {
		var GBLTut_ConsoleService = Components.classes['@mozilla.org/consoleservice;1'].getService(Components.interfaces.nsIConsoleService);
	    GBLTut_ConsoleService.logStringMessage('Distrust: ' + aMessage + '\n');
		dump('Distrust: ' + aMessage + '\n');
	}
}

function updatePrefValues(prefMngr) {	
	try {
		cookiePref = prefMngr.getBoolPref("distrust.core.cookies");
		diskCachePref = prefMngr.getBoolPref("distrust.core.disk_cache");
		formInfoPref = prefMngr.getBoolPref("distrust.core.form_info");
		historyPref = prefMngr.getBoolPref("distrust.core.history");
		downloadsPref = prefMngr.getBoolPref("distrust.core.downloads");
		undoTabsPref = prefMngr.getBoolPref("distrust.core.tabs");
		sloPref = prefMngr.getBoolPref("distrust.core.slo");
	}
	catch (e) {
		cookiePref = true;
		diskCachePref = true;
		formInfoPref = true;
		historyPref = true;
		downloadsPref = true;
		undoTabsPref = true;
		sloPref = true;
		logMsg("Prefs not set yet - exiting");
	}		
}

/***************************************************/

// This code is based upon - from http://forums.mozillazine.org/viewtopic.php?t=308369
const CI = Components.interfaces, CC = Components.classes, CR = Components.results;
function Distrust_XPCom() {}

Distrust_XPCom.prototype = {
	classID: Components.ID("{71D415A8-63DF-11DA-8BDE-F66BAD1E3F3A}"),
	contractID: "@gness.com/firefox/distrust;1",
	classDescription: "Distrust XPCom",
	browserWindows: [],
	
	QueryInterface: function(aIID) {
		if( !aIID.equals(CI.nsISupports) && !aIID.equals(CI.nsIObserver) && !aIID.equals(CI.dtIDistrustService))
			throw CR.NS_ERROR_NO_INTERFACE;
			
		return this;
	},

	observe: function(aSubject, aTopic, aData) {
		switch(aTopic) {
			case "xpcom-startup":
				// this is run very early, right after XPCOM is initialized, but before
				// user profile information is applied. Register ourselves as an observer
				// for 'profile-after-change' and 'quit-application'
				//			
				var obsSvc = CC["@mozilla.org/observer-service;1"].getService(CI.nsIObserverService);
				obsSvc.addObserver(this, "profile-after-change", false);
				obsSvc.addObserver(this, "quit-application", false);
				//obsSvc.addObserver(this, "dl-done",   false);
				//obsSvc.addObserver(this, "dl-cancel", false);
				//obsSvc.addObserver(this, "dl-failed", false);  
				obsSvc.addObserver(this, "dl-start",  false);  
				//obsSvc.addObserver(this, "xpinstall-download-started", false);  
				//obsSvc.addObserver(this, "xpinstall-dialog-close",     false);
				//obsSvc.addObserver(this, "domwindowclosed", false);				
				break;			
			case "profile-after-change":
				// This happens after profile has been loaded and user preferences have been read.
				// startup code here
				this.checkCrashRecovery();
				this.checkStartupMode();				
				break;
			case "quit-application":
				// shutdown code
				logMsg("quit-application\n");
				if (privacyState == true) {
					logMsg("force closing distrust\n");
					this.toggleDistrustState();
				}
				break;
			case "dl-done":
		       break;
		    case "dl-failed":
				break;
		    case "dl-cancel":
		       //var dl = aSubject.QueryInterface(Components.interfaces.nsIDownload);
		       break;
		    case "dl-start":
			   if (privacyState == true) {//check if this download should be logged 
				   var dl = aSubject.QueryInterface(Components.interfaces.nsIDownload);
				   downloadsToRemove.push(dl.targetFile.path);
				   if (!this.isFF2()) 
				      downloadIDsToRemove.push(dl.id);
			   }
		       break;
		    //case "xpinstall-download-started":
		    //   break;  
		    //case "xpinstall-dialog-close":
		    //   break;       
			//case "domwindowclosed":				
			//	break;
		}
	},
  registerWindow: function(browserWin) {
    var existing;
	logMsg("resgitering " + browserWin);
    for (var i = 0; existing = this.browserWindows[i]; i++) {
      if (existing == browserWin) {
        throw new Error("Browser window has already been registered.");
      }
    }
	logMsg("ui component set OK");
    this.browserWindows.push(browserWin);

	//try to obtain the flash dir
	//this is done here since the platform info is taken from the browser window. I couln't find any better way to do it.
	//so we have to wait until there is an existing window to ask for the platform.
	if (firstWindowRegistering == true) {
		firstWindowRegistering = false;
		this.getFlashDir();
	}
  },
  unregisterWindow: function(browserWin) {
    var existing;

    for (var i = 0; existing = this.browserWindows[i]; i++) {
      if (existing == browserWin) {
        this.browserWindows.splice(i, 1);
        return;
      }
    }
   },
   getIsActive: function() {
	   return privacyState;
   },
   toggleState: function() {
	   logMsg("Toggling state");
	   this.toggleDistrustState();
	   //this.printFormHistoryInfo();
   		for (var i = 0; existing = this.browserWindows[i]; i++) {
      		existing.updateStatusImage(privacyState);
	    }		
   },
   toggleFormFillPref:function() {
	   var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		
		if (privacyState == true) {
			origFormFill = prefMngr.getBoolPref(FORM_FILL_PREF);			
			if ( origFormFill != false) {			
				logMsg('setting form fill state as false');
				prefMngr.setBoolPref(FORM_FILL_PREF,false);
			}
			else {
				logMsg('form fill pref OK - nothing to be done here');
			}
			//save the old value to prvent crash mess
			prefMngr.setBoolPref(DT_CRASH_RECOVER_FORM_FILL_VAL,origFormFill);
		}
		else {
			this.setOrigFormFillPref(prefMngr);
		}
	},
	setOrigFormFillPref:function(prefMngr) {
		prefMngr.setBoolPref(FORM_FILL_PREF,origFormFill);
		logMsg('Setting form fill pref to old state: ' + origFormFill);
	},
	toggleMaxUndoTabsPref:function() {
	   var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		
		if (privacyState == true) {
			try {
				origMaxUndoTabs = prefMngr.getIntPref(MAX_UNDO_TABS_PREF);
			}
			catch (e) {// the MAX_UNDO_TABS_PREF pref won't exists mostly
			}

			if ( origMaxUndoTabs != 0) {			
				logMsg('setting max undo tabs state to 0');
				prefMngr.setIntPref(MAX_UNDO_TABS_PREF,0);
			}
			else {
				logMsg('max undo tabs OK - nothing to be done here');
			}
			//save the old value to prvent crash mess
			prefMngr.setIntPref(DT_CRASH_RECOVER_MAX_UNDO_TABS_VAL,origMaxUndoTabs);
		}
		else {
			this.setOrigMaxUndoTabsPref(prefMngr);
		}
	},
	setOrigMaxUndoTabsPref:function(prefMngr) {
		prefMngr.setIntPref(MAX_UNDO_TABS_PREF,origMaxUndoTabs);
		logMsg('Setting max undo tabs pref to old state: ' + origMaxUndoTabs);
	},
    toggleCookieStatePref:function() {	

		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		
		if (privacyState == true) {
			origLifetimeBehavior = prefMngr.getIntPref(COOKIE_LIFETIME_PREF);
			if ( origLifetimeBehavior != accept_session) {			
				logMsg('setting new cookie state as accept_session');
				prefMngr.setIntPref(COOKIE_LIFETIME_PREF,accept_session);
			}			
			else {
				logMsg('cookie pref OK - nothing to be done here');
			}
			//save the old value to prvent crash mess
			prefMngr.setIntPref(DT_CRASH_RECOVER_COOKIE_VAL,origLifetimeBehavior);
		}
		else {
			this.setOrigCookiePref(prefMngr);
		}
	},
	setOrigCookiePref:function(prefMngr) {
		prefMngr.setIntPref(COOKIE_LIFETIME_PREF,origLifetimeBehavior);
		logMsg('Setting cookie pref to old state: ' + origLifetimeBehavior);
	},
	toggleDiskCacheStatePref:function() {	

		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		
		if (privacyState == true) {
			origDiskCache = prefMngr.getBoolPref(DISK_CACHE_PREF);
			if ( origDiskCache != false) {			
				logMsg('setting disk cache state as false');
				prefMngr.setBoolPref(DISK_CACHE_PREF,false);
			}
			else {
				logMsg('disk cache pref OK - nothing to be done here');
			}
			//save the old value to prvent crash mess
			prefMngr.setBoolPref(DT_CRASH_RECOVER_DISK_CACHE_VAL,origDiskCache);
		}
		else {
			this.setOrigDiskCachePref(prefMngr);
		}
	},
	setOrigDiskCachePref:function(prefMngr) {
		prefMngr.setBoolPref(DISK_CACHE_PREF,origDiskCache);
		logMsg('Setting disk cache pref to old state: ' + origDiskCache);
	},
	toggleDiskCacheSSLStatePref:function() {	

		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		
		if (privacyState == true) {
			origDiskCacheSSL = prefMngr.getBoolPref(DISK_CACHE_SSL_PREF);
			if ( origDiskCacheSSL != false) {			
				logMsg('setting disk cache SSL state as false');
				prefMngr.setBoolPref(DISK_CACHE_SSL_PREF,false);
			}
			else {
				logMsg('disk cache SSL pref OK - nothing to be done here');
			}
			//save the old value to prvent crash mess
			prefMngr.setBoolPref(DT_CRASH_RECOVER_DISK_CACHE_SSL_VAL,origDiskCacheSSL);
		}
		else {
			this.setOrigDiskCacheSSLPref(prefMngr);
		}
	},
	setOrigDiskCacheSSLPref:function(prefMngr) {
		prefMngr.setBoolPref(DISK_CACHE_SSL_PREF,origDiskCacheSSL);
		logMsg('Setting disk cache SSL pref to old state: ' + origDiskCacheSSL);
	},
	setCrashFlag:function() {	
		var prefMngrBranch = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		prefMngrBranch.setBoolPref(DT_CRASH_RECOVER_FLAG,privacyState);
		if (privacyState == false) {//DT is shutting down so delete all the crash data values
			try {
				logMsg('Removing crash data');
				var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefService);
				var crashBranch = prefMngr.getBranch(DT_CRASH_RECOVER_DATA_BRANCH);
				crashBranch.deleteBranch("");
			}
			catch (e) {
				logMsg('failed to delete crash data');
			}
		}
	},
	recoverFromCrash:function() {
		logMsg('recovering from crash');
		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		try {
			origLifetimeBehavior = prefMngr.getIntPref(DT_CRASH_RECOVER_COOKIE_VAL);
			this.setOrigCookiePref(prefMngr);
		} catch(e) {
			//crash data might no exist and its OK - do nothing
		}
		try {
			origDiskCache = prefMngr.getBoolPref(DT_CRASH_RECOVER_DISK_CACHE_VAL);
			this.setOrigDiskCachePref(prefMngr);
		} catch(e) {
			//crash data might no exist and its OK - do nothing
		}
		try {
			origDiskCacheSSL = prefMngr.getBoolPref(DT_CRASH_RECOVER_DISK_CACHE_SSL_VAL);
			this.setOrigDiskCacheSSLPref(prefMngr);
		} catch(e) {
			//crash data might no exist and its OK - do nothing
		}
		try {
			origFormFill = prefMngr.getBoolPref(DT_CRASH_RECOVER_FORM_FILL_VAL);
			this.setOrigFormFillPref(prefMngr);
		} catch(e) {
			//crash data might no exist and its OK - do nothing
		}
		try {
			origMaxUndoTabs = prefMngr.getIntPref(DT_CRASH_RECOVER_MAX_UNDO_TABS_VAL);
			this.setOrigMaxUndoTabsPref(prefMngr);
		} catch(e) {
			//crash data might no exist and its OK - do nothing
		}
		this.setCrashFlag();
	},
	clearHistoryEntriesFF2:function() {		
		var RDF = Components.classes["@mozilla.org/rdf/rdf-service;1"].getService(Components.interfaces.nsIRDFService);
		var historyDS = RDF.GetDataSource('rdf:history');
		//make sure the history is loaded already
		var remote = historyDS.QueryInterface(Components.interfaces.nsIRDFRemoteDataSource);
	
		if ((remote.loaded == false) || (historyDS == null)){
			
			logMsg('history is not loaded - can not continue');
			return;
		}
	
		//beginUpdateBatch and endUpdateBatch are the magic functions that tell the UI to update itself once I'm done messing up the history RDF
		var counter = 0;		
		historyDS.beginUpdateBatch();
		
		var elemsToRemove = new Array();
		
		try {
			var DTStartTime = initTime.getTime();
			var elems = historyDS.GetAllResources();
			while(elems.hasMoreElements()) {
				counter = counter+1;
				var elem = elems.getNext();//get history elements one by one
				elem = elem.QueryInterface(Components.interfaces.nsIRDFResource);
				//logMsg("Checking History Element --> " + elem.Value + " <--");
				
				//I want to check dates
				var dateArc = RDF.GetResource(NC_NS + "Date"); 
				
				//give me all the dates targets
				var nodeValue = historyDS.GetTarget(elem,dateArc,true);
				if (nodeValue instanceof Components.interfaces.nsIRDFDate) {
					//logMsg("Checking DATE !!! --> " + new Date(nodeValue.Value/1000).toGMTString() + " <--");
						//check if the date of this history entry is after the initTime
						if (DTStartTime < nodeValue.Value/1000)    {
							logMsg("DATE IS IN SESSION - REMOVING");
							//ok this is a date to remove - kill it and all its children
							//Removing this now will disrupt the enumeration loop we will miss some items.
							//instead of removing it right now - add it to an array and remove all the items in batch
							elemsToRemove.push(elem);
							//deleteEntryFromHistory(elem.Value);//old code left for future reference
						}
				}
				
		/*		//old code left for future reference
				var arcsOut = null;
				// okay, ArcLabelsOut will give us all the "arcs",
				// or resources with children, in this RDF graph
				arcsOut = historyDS.ArcLabelsOut(elem);
				//logMsg('**************************arcCursor is :' + arcCursor);
				//showArcs(historyDS,elem,arcsOut);
		
				while(arcsOut.hasMoreElements()) {
					var thisArc = arcsOut.getNext().QueryInterface(Components.interfaces.nsIRDFResource);
					logMsg("Checking Arc --> " + thisArc.Value + " <--");
					
					if ((thisArc != null) && (thisArc.Value == "rdf:http://home.netscape.com/NC-rdf#Date")) {
						logMsg("Found Date Arc --> " + thisArc.Value + " <--");
						var nodeValue = historyDS.GetTarget(elem,thisArc,true);
						if (nodeValue instanceof Components.interfaces.nsIRDFDate) {
						logMsg("***FOUND DATE !!! --> " + nodeValue.Value + " <--");
						logMsg("***FOUND DATE !!! --> " + new Date(thisTarget.Value/1000).toGMTString() + " <--");
							if (initTime.getTime() < thisTarget.Value/1000)
								logMsg("~~~~~~DATE IS IN SESSION"); 
							
						}
						break;
					}
				}
		*/
			}
		}
		catch(e) {
		  logMsg("Exception: History not ready");
		  return;
	    }
			

		logMsg("Gone Over " + counter + " elements");
		logMsg("Removing " + elemsToRemove.length + " elements");
		var idx = null;
		var containment = RDF.GetResource("http://home.netscape.com/NC-rdf#child");
		var root = RDF.GetResource("NC:HistoryRoot");
		if ((root != null) && (containment != null)) {
			for (idx in elemsToRemove) {
				historyDS.Unassert(root, containment, elemsToRemove[idx]);
			}							
		}
		else
			logMsg("failed to remove history entries");

		delete elemsToRemove;
		
		//ok we are all done - clean up
		historyDS.Flush();
		historyDS.endUpdateBatch();
	},
	clearHistoryEntriesFF3:function() {
		var historyService = Components.classes["@mozilla.org/browser/nav-history-service;1"]
                               .getService(Components.interfaces.nsINavHistoryService);
		var result;
		try {                             
		    var query = historyService.getNewQuery();
		    var options = historyService.getNewQueryOptions();
		    
		    options.resultType = options.RESULTS_AS_URI
		
		    query.beginTimeReference = query.TIME_RELATIVE_EPOCH ;
				query.beginTime = initTime.getTime()*1000; //difference between milli and micro
				query.endTimeReference = query.TIME_RELATIVE_NOW;
				query.endTime = 0; // now
				
                      
				result = historyService.executeQuery(query, options);
		}
		catch(e) {
		  logMsg("Exception: History not ready");
		  return;
	    }
			
		var browserHistory = Components.classes["@mozilla.org/browser/nav-history-service;1"]
                               .getService(Components.interfaces.nsIBrowserHistory);
		
		var rootNode = result.root;
    rootNode.containerOpen = true;
    var cc = rootNode.childCount;
    
    var ios = Components.classes["@mozilla.org/network/io-service;1"]
                    .getService(Components.interfaces.nsIIOService);
	  
	  var elemsToRemove = new Array();
		for (var i=0;i<cc;i++) {
			
			var node = rootNode.getChild(i);
				
			if (node.type == node.RESULT_TYPE_URI || node.RESULT_TYPE_QUERY) {
				var URI = ios.newURI(node.uri,null,null);
				elemsToRemove.push(URI);
				//removing browser history here results in shortening of the queryresult list and going out of bounds for the getchild
				//therefore store the uri's in a list and delete them all later
			}
			else 
				logMsg("not a URI");
				
			}
    rootNode.containerOpen = false;
		
		for (idx in elemsToRemove) {
			browserHistory.removePage(elemsToRemove[idx]);
		}

	},
	clearDownloadedEntries:function() {
		if (downloadsToRemove.length <=0) {
			logMsg('no downloads to remove');
			return;
		}
		
		var RDF = Components.classes["@mozilla.org/rdf/rdf-service;1"].getService(Components.interfaces.nsIRDFService);
		const dlmgrContractID = "@mozilla.org/download-manager;1";
		const dlmgrIID = Components.interfaces.nsIDownloadManager;
		var downloadMgr = Components.classes[dlmgrContractID].getService(dlmgrIID);
		if (downloadMgr == null) {
			logMsg('download manager cannot be reached - can not continue');
			return;
		}
		
		var downloadsOnDisk = new Array();
		
		logMsg("Removing " + downloadsToRemove.length + " downloads");
		for (var i = 0; i < downloadsToRemove.length; i++) {
			try {
				if (!this.isFF2()) {
				    logMsg("Removing " + downloadsToRemove[i] + "ID:" + downloadIDsToRemove[i] + " download");
				    //note this is now a download id in remove download
				    downloadMgr.removeDownload(downloadIDsToRemove[i]);
				}
				else {
				    logMsg("Removing " + downloadsToRemove[i] + " download");
				    //note this is now a download id in remove download
				    downloadMgr.removeDownload(downloadsToRemove[i]);
				}				
			}
			catch(e) {
		  		logMsg("Exception!!! " + downloadsToRemove[i] + " Was already removed from list");
		  	}
			var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
			if (file != null) {
				file.initWithPath(downloadsToRemove[i]);
				if ((file.exists() == true) && (file.isFile() == true)) {
					downloadsOnDisk.push(downloadsToRemove[i]);
				}
			}
		}
		
		if (downloadsOnDisk.length > 0) {
			logMsg('Found ' + downloadsOnDisk.length + ' on disk');


			// Open topic in new window.
			var params = Components.classes["@mozilla.org/embedcomp/dialogparam;1"].createInstance(Components.interfaces.nsIDialogParamBlock);
			params.SetNumberStrings(downloadsOnDisk.length);
			for (var idx = 0; idx < downloadsOnDisk.length; idx++) {
				params.SetString(idx, downloadsOnDisk[idx]);
			}

			var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
			var dlDiskPref = true;
			try {
				dlDiskPref = prefMngr.getBoolPref("distrust.core.downloads_disk");
			}
			catch (e) {
			}
			if (dlDiskPref == true) {
				var ww = Components.classes["@mozilla.org/embedcomp/window-watcher;1"]         	.getService(Components.interfaces.nsIWindowWatcher);
				ww.openWindow(null, "chrome://dt/content/dt-downloads-dlg.xul",
                	        "dt-downloads-dlg", "centerscreen,chrome,resizable=yes,dependent=yes", params);
			}
		}
		
		//all done clear the array
		for (var j = downloadsToRemove.length; j > 0 ; j--) {
			downloadsToRemove.pop();
			if (!this.isFF2())
			    downloadIDsToRemove.pop();
		}
		
	},
	toggleDistrustState:function() {		
		logMsg("toggling DT state");
		
		privacyState = !privacyState;
		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		updatePrefValues(prefMngr);
		if (privacyState == true) {			
		    origLifetimeBehavior = prefMngr.getIntPref(COOKIE_LIFETIME_PREF);
			origDiskCache = prefMngr.getBoolPref(DISK_CACHE_PREF);
			origDiskCacheSSL = prefMngr.getBoolPref(DISK_CACHE_SSL_PREF);
			if (origLifetimeBehavior == -3) {//meaning we failed to get a real pref
				logMsg('Cookie lifetimeBehavior read as: ' + lifetimeBehavior +' setting to normal');
				origLifetimeBehavior = accept_normally;
			}			
		}
		this.setCrashFlag();
		if (undoTabsPref == true)
			this.toggleMaxUndoTabsPref();
		if (cookiePref == true) 
			this.toggleCookieStatePref();
		if (diskCachePref == true) {
			this.toggleDiskCacheStatePref();
			this.toggleDiskCacheSSLStatePref();
		}
				
		if (formInfoPref == true) 
			this.toggleFormFillPref();
		
		if (privacyState == true) {//we are going into privacy mode so just take the current time
			initTime = new Date();			
		}
		else {
			if (historyPref == true) {
				if (this.isFF2())
					this.clearHistoryEntriesFF2();
				else
					this.clearHistoryEntriesFF3();
			}
			if (downloadsPref == true) 
				this.clearDownloadedEntries();
			if (sloPref == true) {				
				var flashDir = this.getFlashDir();
				logMsg("detected flash dir: " + flashDir.persistentDescriptor);
				if (flashDir != null && flashDir != undefined)
					this.clearLSOs(flashDir);
			}
		}
	},
	checkCrashRecovery:function() {
		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		if (prefMngr != null) {
			try {
				if (prefMngr.getBoolPref(DT_CRASH_RECOVER_FLAG) == true) {
					this.recoverFromCrash();
				}
			}
			catch (e) {
				//nothing to do - the fref doesn't exist yet so just don't do anything
			}
		}
	},
	checkStartupMode:function() {
		logMsg("Checking autostart");
		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		if (prefMngr != null) {
			try {
				if (prefMngr.getBoolPref("distrust.core.autostart") == true) {
					logMsg("autostarting according to pref");
					this.toggleDistrustState();
				}
			}
			catch (e) {
				//nothing to do - the fref doesn't exist yet so just don't do anything
			}
		}
	},
	printFormHistoryInfo:function() {
		logMsg("------------Form History------------");
		this.browserWindows[0].openDialog("chrome://browser/content/searchDialog.xul", "","chrome,dialog,resizable,modal");
		var formHistory = Components.classes['@mozilla.org/satchel/form-history;1'].getService(Components.interfaces.nsIFormHistory);
		if (formHistory != null) {
			logMsg("got form history IFS - has " + formHistory.rowCount + " items");
			for(var i = 0; i < formHistory.rowCount; i++) {
				 var name={value:""};
    		     var value={value:""};
                 formHistory.getEntryAt(i,name,value);
				 logMsg(i + ". name: " + name.value + " value: " + value.value);
			}
		}
		else
			logMsg("Couln't get form manager");
		logMsg("************Form History*************");
	},
	// automatic detection for Flash Apps directory
	getFlashDir:function() {
		try {
			if (this.browserWindows[0] == null)
				return;
		}catch (e) {
				//CHECK - need to see if there is another way to get the OS platform string
		}

		//get the platform from the browser window
		var osPlat = this.browserWindows[0].getPlatform();
		var dtPrefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService).getBranch("distrust.core.");
		var LocalFile = new Components.Constructor("@mozilla.org/file/local;1", "nsILocalFile");
		var flashDir = new LocalFile();
		var varDir = new LocalFile();
		var flashDirPrefVal = null;
		if (dtPrefs.prefHasUserValue("flashAppDir"))
			flashDirPrefVal = dtPrefs.getCharPref("flashAppDir");
		if ((flashDirPrefVal == null) || (flashDirPrefVal == undefined)) {
			if (osPlat == "Win32") {
				var winDir = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("AppData", Components.interfaces.nsILocalFile);
				flashDir = winDir;
				flashDir.appendRelativePath('\Macromedia');
				flashDir.appendRelativePath('\Flash Player');
				if ((flashDir.exists()) && (flashDir.isDirectory())) {
					varDir = flashDir;
					dtPrefs.setCharPref("flashAppDir", varDir.path);
				} else {
					flashDir = winDir;
					flashDir.appendRelativePath('\Roaming');//windows vista thing
					flashDir.appendRelativePath('\Macromedia');
					flashDir.appendRelativePath('\Flash Player');
					if ((flashDir.exists()) && (flashDir.isDirectory())) {
						varDir = flashDir;
						dtPrefs.setCharPref("flashAppDir", varDir.path);
					} else {
						flashDir = winDir;
						flashDir.appendRelativePath('\Macromedia');
						if ((flashDir.exists()) && (flashDir.isDirectory())) {
							varDir = flashDir;
							dtPrefs.setCharPref("flashAppDir", varDir.path);
						} else {
							varDir = "";
							dtPrefs.setCharPref("flashAppDir", "");
						}
					}
				}
			} else if ((osPlat == "MacPPC") || (osPlat == "MacIntel")) {
				var macDir = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("UsrPrfs", Components.interfaces.nsILocalFile);
				flashDir = macDir;
				flashDir.appendRelativePath('Macromedia');
				flashDir.appendRelativePath('Flash Player');
				if ((flashDir.exists()) && (flashDir.isDirectory())) {
					varDir = flashDir;
					dtPrefs.setCharPref("flashAppDir", varDir.path);
				} else {
					flashDir = macDir;
					flashDir.appendRelativePath('\Macromedia');
					if ((flashDir.exists()) && (flashDir.isDirectory())) {
						varDir = flashDir;
						dtPrefs.setCharPref("flashAppDir", varDir.path);
					} else {
						varDir = ""; 
						dtPrefs.setCharPref("flashAppDir", "");
					}
				}
			} else if (osPlat.indexOf("Linux") == 0) {
				var homeDir = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("Home", Components.interfaces.nsILocalFile);
				flashDir = homeDir;
				flashDir.appendRelativePath('.macromedia');
				flashDir.appendRelativePath('Flash_Player');
				if ((flashDir.exists()) && (flashDir.isDirectory())) {
					varDir = flashDir;
					dtPrefs.setCharPref("flashAppDir", varDir.path);
				} else {
					flashDir = homeDir;
					flashDir.appendRelativePath('.macromedia');
					if ((flashDir.exists()) && (flashDir.isDirectory())) {
						varDir = flashDir;
						dtPrefs.setCharPref("flashAppDir", varDir.path);
					} else {
						varDir = "";
						dtPrefs.setCharPref("flashAppDir", ""); 
					}
				}  
			} else {
				var homeDir = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("Home", Components.interfaces.nsILocalFile);
				flashDir = homeDir;
				flashDir.appendRelativePath('.macromedia');
				flashDir.appendRelativePath('Macromedia');
				flashDir.appendRelativePath('Flash \Player');
				if ((flashDir.exists()) && (flashDir.isDirectory())) {
					varDir = flashDir;
					dtPrefs.setCharPref("flashAppDir", varDir.path);
				} else {
					flashDir = homeDir;
					flashDir.appendRelativePath('.macromedia');
					flashDir.appendRelativePath('Macromedia');
					if ((flashDir.exists()) && (flashDir.isDirectory())) {
						varDir = flashDir;
						dtPrefs.setCharPref("flashAppDir", varDir.path);
					} else {
						varDir = "";
						dtPrefs.setCharPref("flashAppDir", ""); 
					}
				}  
			}  
		} else {
			if ((flashDirPrefVal != null) && (flashDirPrefVal != "")) {
				logMsg("Flash Dir Loaded From Pref " + flashDirPrefVal);
				varDir.initWithPath(flashDirPrefVal);
			} else {
				varDir = "";
			}
		}
		return varDir;
	},
	clearLSOs:function(someDir) { 
		var dirIterator = someDir.directoryEntries;
		var currentFile = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
		var directoriesArray = new Array();
		var mode = 'clear';

		try {	
			while (dirIterator.hasMoreElements) {
				var currentFile = dirIterator.getNext();
				if (currentFile) {
					currentFile.QueryInterface(Components.interfaces.nsILocalFile);
					if (currentFile.isFile()) {
						var leaf  = currentFile.leafName;
						var dotIndex  = leaf.lastIndexOf('.');
						var extension = (dotIndex >= 0) ? leaf.substring(dotIndex+1) : "";
						if ((extension == "sol")||(extension == "fso")) {
							if (initTime.getTime() < currentFile.lastModifiedTime) {
								//logMsg("Removing SLO: " + currentFile.persistentDescriptor);
								currentFile.remove(false);
							}
						}
					} else if (currentFile.isDirectory()) {
						directoriesArray.push(currentFile);
					}
				} else {
					break;
				}
			}
	
			//go over all the found folders and check if there are LSO's in them
			for (var q = 0; q < directoriesArray.length; q++) {
				this.clearLSOs(directoriesArray[q]);
			}
		}
		catch (e) {
			logMsg("Flash Dir could not be located properly - leaving");
			return;
		}	
	},
	isFF2:function() {
		var prefMngr = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
		var ffVersion = prefMngr.getCharPref(FF_VERSION);
		if(ffVersion[0] == '2')
		    return true;
		else
		    return false;
	}
};

// constructors for objects we want to XPCOMify
//
var gXpComObjects = [Distrust_XPCom];
var gCatObserverName = "distrust_catobserver";
var gCatContractId = Distrust_XPCom.prototype.contractID;


// AFM - generic registration code
//

function NSGetModule(compMgr, fileSpec) {
	gModule._catObserverName = gCatObserverName;
	gModule._catContractId = gCatContractId;
	
	for (var i in gXpComObjects)
		gModule._xpComObjects[i] = new gFactoryHolder(gXpComObjects[i]);
		
	return gModule;
}

function gFactoryHolder(aObj) {
	this.CID        = aObj.prototype.classID;
	this.contractID = aObj.prototype.contractID;
	this.className  = aObj.prototype.classDescription;
	this.factory =
	{
		createInstance: function(aOuter, aIID)
		{
			if (aOuter)
				throw CR.NS_ERROR_NO_AGGREGATION;
				
			return (new this.constructor).QueryInterface(aIID);
		}
	};
	
	this.factory.constructor = aObj;
}

var gModule = {
	registerSelf: function (aComponentManager, aFileSpec, aLocation, aType) {
		aComponentManager.QueryInterface(CI.nsIComponentRegistrar);
		for (var key in this._xpComObjects)
		{
			var obj = this._xpComObjects[key];
			aComponentManager.registerFactoryLocation(obj.CID, obj.className,
			obj.contractID, aFileSpec, aLocation, aType);
		}
		
		var catman = CC["@mozilla.org/categorymanager;1"].getService(CI.nsICategoryManager);
		catman.addCategoryEntry("xpcom-startup", this._catObserverName, this._catContractId, true, true);
		catman.addCategoryEntry("xpcom-shutdown", this._catObserverName, this._catContractId, true, true);
	},

	unregisterSelf: function(aCompMgr, aFileSpec, aLocation) {
		var catman = CC["@mozilla.org/categorymanager;1"].getService(CI.nsICategoryManager);
		catman.deleteCategoryEntry("xpcom-startup", this._catObserverName, true);
		catman.deleteCategoryEntry("xpcom-shutdown", this._catObserverName, true);
		
		aComponentManager.QueryInterface(CI.nsIComponentRegistrar);
		for (var key in this._xpComObjects)
		{
			var obj = this._xpComObjects[key];
			aComponentManager.unregisterFactoryLocation(obj.CID, aFileSpec);
		}
	},

	getClassObject: function(aComponentManager, aCID, aIID)	{
		if (!aIID.equals(CI.nsIFactory))
			throw CR.NS_ERROR_NOT_IMPLEMENTED;
		
		for (var key in this._xpComObjects)
		{
			if (aCID.equals(this._xpComObjects[key].CID))
				return this._xpComObjects[key].factory;
		}
	
		throw CR.NS_ERROR_NO_INTERFACE;
	},

	canUnload: function(aComponentManager) { return true; },
	
	
	_xpComObjects: {},
	_catObserverName: null,
	_catContractId: null
};

//this is the original clearDownloadedEntries functyion
//it should have worked if it was not for bug http://bugzilla.mozilla.org/show_bug.cgi?id=290273
/* 
	clearDownloadedEntries:function() {
		var RDF = Components.classes["@mozilla.org/rdf/rdf-service;1"].getService(Components.interfaces.nsIRDFService);
		const dlmgrContractID = "@mozilla.org/download-manager;1";
		const dlmgrIID = Components.interfaces.nsIDownloadManager;
		var downloadMgr = Components.classes[dlmgrContractID].getService(dlmgrIID);
		var downloadsDS = downloadMgr.datasource;

		//make sure the downloads RDF is loaded already
		var remote = downloadsDS.QueryInterface(Components.interfaces.nsIRDFRemoteDataSource);
	
		if ((remote.loaded == false) || (downloadsDS == null)){
			
			logMsg('downloads is not loaded - can not continue');
			return;
		}
	
		var counter = 0;		
		var elemsToRemove = new Array();
		logMsg("BASE DATE !!! --> " + initTime.toGMTString() + " <--");
		
		var elems = downloadsDS.GetAllResources();
		while(elems.hasMoreElements()) {
			countefalser = counter+1;
			var elem = elems.getNext();//get downloads elements one by one
			elem = elem.QueryInterface(Components.interfaces.nsIRDFResource);
			logMsg("Checking Downloaded Element --> " + elem.Value + " <--");
			
			//I want to check dates
			var dateArc = RDF.GetResource(NC_NS + "DateStarted"); 
			
			//give me all the dates targets
			var nodeValue = downloadsDS.GetTarget(elem,dateArc,true);
			if (nodeValue instanceof Components.interfaces.nsIRDFDate) {
				logMsg("Checking DATE !!! --> " + new Date(nodeValue.Value/1000).toGMTString() + " <--");
					//check if the date of this download entry is after the initTime
					if (initTime.getTime() < nodeValue.Value/1000)    {
						logMsg("DATE IS IN SESSION - REMOVING");
						//ok this is a date to remove - kill it and all its children
						//Removing this now will disrupt the enumeration loop we will miss some items.
						//instead of removing it right now - add it to an array and remove all the items in batch
						elemsToRemove.push(elem);
					}
				
			}
		}

		logMsg("Gone Over " + counter + " elements");
		logMsg("Removing " + elemsToRemove.length + " elements");
		var idx = null;
		for (idx in elemsToRemove) {
			//downloadMgr.removeDownload(elemsToRemove[idx].Value);
		}
		
		delete elemsToRemove;		
	},*/
